//
//  NSString+ParseURLString.h
//  王者灯塔
//
//  Created by tarena on 16/1/10.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (ParseURLString)

-(NSString*)parseURLString;

@end
