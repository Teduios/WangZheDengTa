//
//  NSData+alalysisHtml.m
//  王者灯塔
//
//  Created by tarena on 16/1/10.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "NSData+alalysisHtml.h"

@implementation NSData (alalysisHtml)

+(NSArray *)analysisHtml:(NSData *)data ByString:(NSString *)str
{
    NSStringEncoding enc = CFStringConvertEncodingToNSStringEncoding (kCFStringEncodingGB_18030_2000);
    NSString *dataString = [[NSString alloc] initWithData:data encoding:enc];
    
    if (dataString.length == 0)
    {
        dataString = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    }
    
    NSRegularExpression *regularExpression = [[NSRegularExpression alloc] initWithPattern:str options:NSRegularExpressionCaseInsensitive|NSRegularExpressionDotMatchesLineSeparators error:nil];
    
    NSArray * arrayOfAllMatches = [regularExpression matchesInString:dataString options:0 range:NSMakeRange(0 ,dataString.length)];
    NSMutableArray *resultArray = [[NSMutableArray alloc] init];
    
    for (NSTextCheckingResult *match in arrayOfAllMatches)
    {
        NSString* substringForMatch = [dataString substringWithRange:match.range];
        [resultArray addObject:substringForMatch];
    }
    return resultArray;
}

@end
