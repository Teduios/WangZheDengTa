//
//  NSString+getInfomation.h
//  王者灯塔
//
//  Created by tarena on 16/1/10.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (getInfomation)

-(NSString*)getInfomation:(NSString*)Str;

-(NSArray*)getInfomations:(NSString*)Str;

-(NSMutableString*)deleteString:(NSArray*)array;


@end
