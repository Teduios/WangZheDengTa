//
//  NSString+getInfomation.m
//  王者灯塔
//
//  Created by tarena on 16/1/10.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "NSString+getInfomation.h"

@implementation NSString (getInfomation)

- (NSString *)getInfomation:(NSString *)str
{
    NSRegularExpression *regularExpression = [[NSRegularExpression alloc] initWithPattern:str options:NSRegularExpressionCaseInsensitive|NSRegularExpressionDotMatchesLineSeparators error:nil];
    [regularExpression firstMatchInString:self options:NSMatchingAnchored range:NSMakeRange(0 ,self.length)];
    return [self substringWithRange:[[regularExpression firstMatchInString:self options:NSMatchingReportCompletion range:NSMakeRange(0 ,self.length)] rangeAtIndex:0]];
}
- (NSArray *)getInfomations:(NSString *)str
{
    NSRegularExpression *regularExpression = [[NSRegularExpression alloc] initWithPattern:str options:NSRegularExpressionCaseInsensitive|NSRegularExpressionDotMatchesLineSeparators error:nil];
    NSArray * arrayOfAllMatches = [regularExpression matchesInString:self options:0 range:NSMakeRange(0 ,self.length)];
    NSMutableArray *resultArray = [[NSMutableArray alloc] init];
    
    for (NSTextCheckingResult *match in arrayOfAllMatches)
    {
        NSString* substringForMatch = [self substringWithRange:match.range];
        [resultArray addObject:substringForMatch];
    }
    
    return resultArray;
}
- (NSMutableString *)deleteString:(NSArray *)array
{
    NSMutableString *mStr = [self mutableCopy];
    
    for (NSUInteger i = 0; i < [array count]; i++)
    {
        NSRange range;
        while ((range = [mStr rangeOfString:array[i]]).location != NSNotFound)
        {
            [mStr deleteCharactersInRange:range];
        }
    }
    
    return mStr;
}

@end
