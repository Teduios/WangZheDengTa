//
//  NSString+ParseURLString.m
//  王者灯塔
//
//  Created by tarena on 16/1/10.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "NSString+ParseURLString.h"

@implementation NSString (ParseURLString)

-(NSString *)parseURLString
{
    NSString *result = ( NSString *)
    /**IOS9以后被淘汰了，但还可以用*/
    CFBridgingRelease(CFURLCreateStringByReplacingPercentEscapesUsingEncoding(kCFAllocatorDefault,(CFStringRef)self,CFSTR(""),kCFStringEncodingUTF8));
    
    return result;

}

@end
