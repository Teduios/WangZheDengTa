//
//  NSData+alalysisHtml.h
//  王者灯塔
//
//  Created by tarena on 16/1/10.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSData (alalysisHtml)

+ (NSArray *)analysisHtml:(NSData *)data ByString:(NSString *)str;

@end
