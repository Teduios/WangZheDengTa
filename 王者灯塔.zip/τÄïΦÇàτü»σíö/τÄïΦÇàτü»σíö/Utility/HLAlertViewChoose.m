//
//  HLAlertViewChoose.m
//  王者灯塔
//
//  Created by tarena on 16/1/29.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "HLAlertViewChoose.h"

#define WIDTH [[UIScreen mainScreen] bounds].size.width
#define HEIGHT [[UIScreen mainScreen] bounds].size.height

@implementation HLAlertViewChoose

{
    UIView *_target;
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

- (instancetype)initWithtitle:(NSString *)title target:(UIView *)target
{
    if (self = [super init])
    {
        self.frame = CGRectMake(0, 0, 200, 150);
        self.center = CGPointMake(WIDTH / 2, HEIGHT / 2);
        self.backgroundColor = [UIColor clearColor];
        self.layer.cornerRadius = 20;
        self.layer.masksToBounds = YES;
        
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, self.frame.size.width, 150)];
        label.text = title;
        label.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.3];
        label.textAlignment = NSTextAlignmentCenter;
        label.font = [UIFont boldSystemFontOfSize:20];
        label.textColor = [UIColor whiteColor];
        label.numberOfLines = 0;
        label.userInteractionEnabled = YES;
        [self addSubview:label];
        
        
        UIButton *ok = [UIButton buttonWithType:UIButtonTypeSystem];
        ok.frame = CGRectMake(0, 100, 100, 50);
        [ok setTitle:@"是" forState:UIControlStateNormal];
        [ok setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        ok.backgroundColor = [UIColor clearColor];
        ok.titleLabel.font = [UIFont boldSystemFontOfSize:20];
        ok.tag = 10;
        [ok addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:ok];
        
        UIButton *cancle = [UIButton buttonWithType:UIButtonTypeSystem];
        cancle.frame = CGRectMake(100, 100, 100, 50);
        [cancle setTitle:@"否" forState:UIControlStateNormal];
        [cancle setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        cancle.backgroundColor = [UIColor clearColor];
        cancle.titleLabel.font = [UIFont boldSystemFontOfSize:20];
        cancle.tag = 20;
        [cancle addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:cancle];
        
        
        
        
        _target = target;
        
        [_target addSubview:self];
    }
    
    return self;
}

- (void)show
{
    
    [UIView animateWithDuration:2 animations:^{
        self.alpha = 0;
    } completion:^(BOOL finished) {
        [self removeFromSuperview];
    }];
}

- (void)btnClick:(UIButton *)btn
{
    if (btn.tag == 10)
    {
        self.btnClick(YES);
    }
    else
    {
        self.btnClick(NO);
    }
    
    [self show];
}


@end
