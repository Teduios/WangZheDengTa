//
//  LGViewController.m
//  LGSublimationView
//
//  Created by nxl on 15/11/23.
//  Copyright © 2015年 nxl. All rights reserved.
//

#import "WelcomeViewController.h"
#import "LGSublimationView.h"
#import "HLBarViewController.h"

#define WIDTH [UIScreen mainScreen].bounds.size.width
#define HEIGHT [UIScreen mainScreen].bounds.size.height
@interface WelcomeViewController () <LGSublimationViewDelegate>

@end

@implementation WelcomeViewController


#pragma mark - Life Cycle

- (void)loadView
{
    [super loadView];
    
    LGSublimationView *lgSublimer = [[LGSublimationView alloc]initWithFrame:self.view.bounds];
    
    NSMutableArray*views = [NSMutableArray new];
    for (int i  = 1; i<=4; i++) {
        UIImageView *view = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height)];
        view.image = [UIImage imageNamed:[NSString stringWithFormat:@"%i%i.png",i,i]];
        view.contentMode = UIViewContentModeScaleAspectFill;
        [views addObject:view];
    }
    
    lgSublimer.titleLabelTextColor = [UIColor whiteColor];
    lgSublimer.descriptionLabelTextColor = [UIColor whiteColor];
    lgSublimer.delegate = self;
    lgSublimer.titleLabelFont = [UIFont fontWithName:@"HelveticaNeue-Light" size:20];
    lgSublimer.descriptionLabelFont = [UIFont fontWithName:@"HelveticaNeue-UltraLight" size:20];
    lgSublimer.titleStrings = @[@"LOL灯塔",
                                @"LOL灯塔",
                                @"LOL灯塔",
                                @"LOL灯塔"];
    lgSublimer.descriptionStrings = @[@"一手信息",
                                      @"最新赛事",
                                      @"热点视频",
                                      @"美女玩家"];
    
    
    lgSublimer.viewsToSublime = views;
    
    UIView* shadeView = [[UIView alloc]initWithFrame:lgSublimer.frame];
    shadeView.backgroundColor = [UIColor blackColor];
    shadeView.alpha = 0.2;
    
    lgSublimer.inbetweenView = shadeView;
    
    [self.view addSubview:lgSublimer];
    
    
    
    
    
    
    
}

#pragma mark - LGSublimationViewDelegate

-(void)lgSublimationView:(LGSublimationView *)view didEndScrollingOnPage:(NSUInteger)page
{
    
    if ( page==4 ) {
        UIButton *button = [[UIButton alloc]initWithFrame:CGRectMake(WIDTH/2-90,HEIGHT-120,180,60)];
        [button setTitle:@"点击进入LOL灯塔→" forState:UIControlStateNormal];
        [button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [button setTitleColor:[UIColor orangeColor] forState:UIControlStateHighlighted];
        [button addTarget:self action:@selector(click) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview:button];
        
    }
    
}

-(void)click
{
    UIStoryboard* story=[UIStoryboard storyboardWithName:@"Main" bundle:nil];
    HLBarViewController* vc=[story instantiateViewControllerWithIdentifier:@"barVC"];
    [self presentViewController:vc animated:YES completion:nil];
}


@end
