//
//  HLAlertView.m
//  王者灯塔
//
//  Created by tarena on 16/1/29.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "HLAlertView.h"

#define WIDTH [[UIScreen mainScreen] bounds].size.width
#define HEIGHT [[UIScreen mainScreen] bounds].size.height

@implementation HLAlertView

{
    UIView *_target;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

- (instancetype)initWithtitle:(NSString *)title target:(UIView *)target
{
    if (self = [super init])
    {
        self.frame = CGRectMake(0, 0, 200, 150);
        self.center = CGPointMake(WIDTH / 2, HEIGHT / 2-150);
        self.backgroundColor = [UIColor clearColor];
        self.layer.cornerRadius = 20;
        self.layer.masksToBounds = YES;
        
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, self.frame.size.width, self.frame.size.height)];
        label.text = title;
        label.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.3];
        label.textAlignment = NSTextAlignmentCenter;
        label.font = [UIFont boldSystemFontOfSize:18];
        label.textColor = [UIColor whiteColor];
        label.numberOfLines = 0;
        [self addSubview:label];
        
        _target = target;
    }
    
    return self;
}

- (void)show
{
    [_target addSubview:self];
    [UIView animateWithDuration:2 animations:^{
        self.alpha = 0;
    } completion:^(BOOL finished) {
        [self removeFromSuperview];
    }];
}


@end
