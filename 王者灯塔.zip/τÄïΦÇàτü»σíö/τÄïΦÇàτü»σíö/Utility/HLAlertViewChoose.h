//
//  HLAlertViewChoose.h
//  王者灯塔
//
//  Created by tarena on 16/1/29.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HLAlertViewChoose : UIView

- (instancetype)initWithtitle:(NSString *)title target:(UIView *)target;

@property (nonatomic, strong) void(^btnClick)(BOOL go);

- (void)show;


@end
