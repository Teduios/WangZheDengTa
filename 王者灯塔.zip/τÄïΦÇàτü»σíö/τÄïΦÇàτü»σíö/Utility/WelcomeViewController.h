//
//  WelcomeViewController.h
//  test
//
//  Created by bowen_guan on 15/12/24.
//  Copyright © 2015年 bowen_guan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WelcomeViewController : UIViewController

@end
