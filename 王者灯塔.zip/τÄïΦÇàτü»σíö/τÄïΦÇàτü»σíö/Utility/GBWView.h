//
//  GBWView.h
//  test
//
//  Created by bowen_guan on 15/12/24.
//  Copyright © 2015年 bowen_guan. All rights reserved.
//

#import <UIKit/UIKit.h>
@protocol GBWViewDelegate <NSObject>
@end
@interface GBWView : UIView
@property (nonatomic, strong) NSArray *viewToSublime;
@property (nonatomic, strong) NSArray *titleStrings;
@property (nonatomic, strong) NSArray *descriptionStrings;
@property (nonatomic, strong) UIFont *titleLabelFont;
@property (nonatomic, strong) UIColor *titleLabelTextColor;
@property (nonatomic, strong) UIFont *descriptionLabelFont;
@property (nonatomic, strong) UIColor *descriptionLabelTextColor;
@property (nonatomic, strong) UIPageControl *pageControl;
@property (nonatomic, assign) CGFloat titleLabelY;
@property (nonatomic, assign) CGFloat escriptionLabelY;
@property (nonatomic, strong) UIView *inbetweenView;
@property (nonatomic, assign) BOOL isInfinite;

@property (nonatomic,unsafe_unretained) NSObject<GBWViewDelegate>* delegate;


-(void)GBWView:(GBWView*)view didEndScrollingOnPage:(NSUInteger)page;


@end
