//
//  VedioModle.h
//  王者灯塔
//
//  Created by tarena on 16/1/19.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface VedioModle : NSObject

@property (nonatomic, strong) NSString *vid;
@property (nonatomic, strong) NSString *title;
@property (nonatomic, strong) NSString *cover_url;
@property (nonatomic, assign) NSInteger video_length;
@property (nonatomic, assign) NSString *upload_time;

@end
