//
//  HLNetModle.m
//  王者灯塔
//
//  Created by tarena on 16/1/10.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "HLNetModle.h"
#import "AFNetworking.h"

@implementation HLNetModle

+(void)apiGetHttpURL:(NSString *)URL success:(SuccessBlock)success failure:(FailureBlock)failure progress:(Progress)progress
{
    AFHTTPSessionManager* manager=[AFHTTPSessionManager manager];
    /**根据返回类型选择解析方式*/
    if ([URL rangeOfString:@"api.maxjia.com"].location!=NSNotFound) {
        manager.responseSerializer.acceptableContentTypes=[NSSet setWithObject:@"application/json"];
    }else{
        manager.responseSerializer.acceptableContentTypes=[NSSet setWithObject:@"text/html"];
    }
    [manager GET:URL parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
        progress(downloadProgress);
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        success(responseObject);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        failure(error);
    }];
    
}

+(void)htmlGetHttpURL:(NSString *)URL success:(SuccessBlock)success failure:(FailureBlock)failure progress:(Progress)progress
{
    AFHTTPSessionManager* manager=[AFHTTPSessionManager manager];
    manager.responseSerializer=[AFHTTPResponseSerializer serializer];
    
    [manager GET:URL parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
        progress(downloadProgress);
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        success(responseObject);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        failure(error);
    }];
    
}


@end
