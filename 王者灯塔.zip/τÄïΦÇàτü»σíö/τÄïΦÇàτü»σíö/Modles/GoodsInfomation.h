//
//  GoodsInfomation.h
//  王者灯塔
//
//  Created by tarena on 16/1/21.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GoodsInfomation : NSObject
@property (nonatomic, strong) NSString *teamAName;
@property (nonatomic, strong) NSString *teamAIcon;
@property (nonatomic, strong) NSString *timeOrRecord;
@property (nonatomic, strong) NSString *teamBName;
@property (nonatomic, strong) NSString *teamBicon;
@property (nonatomic, strong) NSString *type;
@end
