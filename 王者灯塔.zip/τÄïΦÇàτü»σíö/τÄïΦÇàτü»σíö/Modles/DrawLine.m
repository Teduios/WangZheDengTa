//
//  DrawLine.m
//  王者灯塔
//
//  Created by tarena on 16/1/21.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "DrawLine.h"

@implementation DrawLine

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame])
    {
        self.backgroundColor = [UIColor clearColor];
    }
    
    return self;
}

-(void)drawRect:(CGRect)rect
{
    float height = self.frame.size.height;
    UIColor *color = [UIColor whiteColor];
    [color set];
    
    UIBezierPath *path = [UIBezierPath bezierPath];
    path.lineWidth = 1;
    [path moveToPoint:CGPointMake(0, height)];
    [path addLineToPoint:CGPointMake(self.x - 8, height)];
    [path addLineToPoint:CGPointMake(self.x, height - 8)];
    [path addLineToPoint:CGPointMake(self.x + 8, height)];
    [path addLineToPoint:CGPointMake([UIScreen mainScreen].bounds.size.width, height)];
    [path fill];
}

@end
