//
//  HLNetModle.h
//  王者灯塔
//
//  Created by tarena on 16/1/10.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>
typedef void(^SuccessBlock) (id Object);
typedef void(^FailureBlock) (NSError*error);
typedef void(^Progress) (NSProgress*progress);

@interface HLNetModle : NSObject
/**api请求*/
+(void)apiGetHttpURL:(NSString*)URL success:(SuccessBlock)success failure:(FailureBlock)failure progress:(Progress)progress;
/**超文本请求*/
+(void)htmlGetHttpURL:(NSString*)URL success:(SuccessBlock)success failure:(FailureBlock)failure progress:(Progress)progress;

@end
