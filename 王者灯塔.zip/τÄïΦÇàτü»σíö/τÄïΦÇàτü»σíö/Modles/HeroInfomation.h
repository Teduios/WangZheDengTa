//
//  HeroInfomation.h
//  王者灯塔
//
//  Created by tarena on 16/1/21.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HeroInfomation : NSObject

@property (nonatomic, strong)NSString *icon;
@property (nonatomic, strong)NSString *name;
@property (nonatomic, strong)NSString *win;
@property (nonatomic, strong)NSString *times;
@property (nonatomic, strong)NSString *donav;
@property (nonatomic, assign)NSInteger type;
@property (nonatomic, strong)NSString *mvpCount;

@end
