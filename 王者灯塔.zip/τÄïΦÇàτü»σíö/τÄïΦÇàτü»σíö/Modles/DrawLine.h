//
//  DrawLine.h
//  王者灯塔
//
//  Created by tarena on 16/1/21.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DrawLine : UIView

@property (nonatomic, assign) float x;

@end
