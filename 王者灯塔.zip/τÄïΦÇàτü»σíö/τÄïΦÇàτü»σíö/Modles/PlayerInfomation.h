//
//  PlayerInfomation.h
//  王者灯塔
//
//  Created by tarena on 16/1/21.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PlayerInfomation : NSObject

@property (nonatomic, strong)NSString *icon;
@property (nonatomic, strong)NSString *name;
@property (nonatomic, strong)NSString *win;
@property (nonatomic, strong)NSString *grade;
@property (nonatomic, strong)NSString *score;
@property (nonatomic, strong)NSString *donav;

@property (nonatomic, strong)NSString *type;
@property (nonatomic, strong)NSString *escape;


@end
