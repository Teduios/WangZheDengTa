//
//  NewsModle.h
//  王者灯塔
//
//  Created by tarena on 16/1/10.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NewsModle : NSObject
@property (nonatomic, strong) NSString *ID;
@property (nonatomic, strong) NSString *title;
@property (nonatomic, strong) NSString *icon;
@property (nonatomic, strong) NSString *short_title;
@property (nonatomic,strong) NSString* comment;

- (instancetype)initWithDictionary:(NSDictionary *)keyedValues;
@end
