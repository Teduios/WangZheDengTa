//
//  VedioModle.m
//  王者灯塔
//
//  Created by tarena on 16/1/19.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "VedioModle.h"

@implementation VedioModle

- (void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    
}

@end
