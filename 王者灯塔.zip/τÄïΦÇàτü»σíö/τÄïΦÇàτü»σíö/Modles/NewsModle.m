//
//  NewsModle.m
//  王者灯塔
//
//  Created by tarena on 16/1/10.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "NewsModle.h"

@implementation NewsModle

- (instancetype)initWithDictionary:(NSDictionary *)keyedValues
{
    if (self = [super init])
    {
        self.ID = keyedValues[@"id"];
        self.title = keyedValues[@"title"];
        self.icon = keyedValues[@"icon"];
        self.short_title = keyedValues[@"short"];
        self.comment=keyedValues[@"comment_count"];
    }
    
    return self;
}

@end
