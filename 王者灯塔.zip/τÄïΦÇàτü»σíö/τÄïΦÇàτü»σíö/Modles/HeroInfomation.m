//
//  HeroInfomation.m
//  王者灯塔
//
//  Created by tarena on 16/1/21.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "HeroInfomation.h"

@implementation HeroInfomation
- (id)copyWithZone:(NSZone *)zone
{
    HeroInfomation *hero = [[HeroInfomation allocWithZone:zone] init];
    
    hero.name = self.name;
    hero.icon = self.icon;
    hero.times = self.times;
    hero.win = self.win;
    hero.donav = self.donav;
    hero.type = self.type;
    hero.mvpCount = self.mvpCount;
    return hero;
}

@end
