//
//  GoodsInfomation.m
//  王者灯塔
//
//  Created by tarena on 16/1/21.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "GoodsInfomation.h"

@implementation GoodsInfomation

@end
