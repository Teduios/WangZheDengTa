//
//  HLCenterBar.h
//  王者灯塔
//
//  Created by tarena on 16/1/4.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
@class HLCenterBar;
@protocol HLCenterBarDelegate <UITabBarDelegate>

-(void)tabBarDidClickCenterBar:(HLCenterBar*)bar;

@end

@interface HLCenterBar : UITabBar
@property(nonatomic,weak)id<HLCenterBarDelegate>delegate;

@end
