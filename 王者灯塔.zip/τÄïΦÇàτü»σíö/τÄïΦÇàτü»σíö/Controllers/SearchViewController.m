//
//  SearchViewController.m
//  王者灯塔
//
//  Created by tarena on 16/1/27.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "SearchViewController.h"
#import "SearchList.h"
#import "UIImageView+WebCache.h"
#import "HLSearchTableViewCell.h"
#import "HLPlayerViewController.h"
#import "MJRefresh.h"
#import "PlayerInfomation.h"
#import "CoreData+MagicalRecord.h"
#import "HLNetModle.h"
#import "NSData+alalysisHtml.h"
#import "NSString+getInfomation.h"
#import "HLAlertView.h"

#define WIDTH [UIScreen mainScreen].bounds.size.width
#define HEIGHT [UIScreen mainScreen].bounds.size.height
#define SEARCH_URL @"http://www.lolmax.com/search/?q=%@"
@interface SearchViewController ()<UISearchBarDelegate,UITableViewDataSource,UITableViewDelegate>

@end

@implementation SearchViewController
{
    UISearchBar *_searchBar;
    UITableView *_tableView;
    NSMutableArray *_dataArray;
    NSInteger _flag;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    _flag=1;
    // Do any additional setup after loading the view.
    [self creatSearchBar];
    [self creatTableView];
    [self reloadTableView];
    
}

- (void)creatSearchBar
{
    _searchBar = [[UISearchBar alloc] initWithFrame:CGRectMake(0, 64, WIDTH, 80)];
    _searchBar.placeholder = @"请输入要查询的召唤师名称";
    _searchBar.delegate = self;
    _searchBar.backgroundColor=[UIColor clearColor];
    [self.view addSubview:_searchBar];
}

- (void)creatTableView
{
    _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 144, WIDTH, HEIGHT - 144 - 49) style:UITableViewStylePlain];
    _tableView.backgroundColor = [UIColor clearColor];
    _tableView.backgroundView=[[UIImageView alloc]initWithImage:[UIImage imageNamed:@"7.png"]];
    _tableView.delegate = self;
    _tableView.dataSource = self;
    _tableView.tableFooterView = [[UIView alloc] init];
    [self.view addSubview:_tableView];
    
    _dataArray = [[NSMutableArray alloc] init];
}

- (void)reloadTableView
{
//    for (SearchList *list in [SearchList MR_findAll])
//    {
//        PlayerInfomation *player = [[PlayerInfomation alloc] init];
//        player.name = list.name;
//        player.icon = list.icon;
//        player.donav = list.url;
//        player.type = list.type;
//        
//        [_dataArray addObject:player];
//    }
//    
//    [_tableView reloadData];
}

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar
{
    _flag = 2;
    _tableView.header = [MJRefreshNormalHeader headerWithRefreshingTarget:self refreshingAction:@selector(refresh)];
    [_searchBar resignFirstResponder];
    [_tableView.header beginRefreshing];
    
}

- (void)refresh
{
    [self getData:_searchBar.text];
}

- (void)getData:(NSString *)str
{
    [_dataArray removeAllObjects];
    
    NSString*strc = [str stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSLog(@"%@",str);

    [HLNetModle htmlGetHttpURL:[NSString stringWithFormat:SEARCH_URL,strc] success:^(id Object) {
        NSArray *array =[NSData analysisHtml:Object ByString:@"DoNav.*?</tr>"];
        
        NSMutableString *icon;
        NSMutableString *name;
        NSMutableString *type;
        NSMutableString *donav;
        
        for (NSString *subString in array)
        {
            icon = [[[subString getInfomation:@"src=\".*?\""] getInfomation:@"\".*?\""] mutableCopy];
            NSRange range;
            
            while ((range = [icon rangeOfString:@"\""]).location != NSNotFound)
            {
                [icon deleteCharactersInRange:range];
            }
            
            name = [[[subString getInfomation:@"<div style=\"margin-top: 10px;\">.*?</div>"] getInfomation:@">.*?<"] mutableCopy];
            
            [name deleteCharactersInRange:[name rangeOfString:@">"]];
            [name deleteCharactersInRange:[name rangeOfString:@"<"]];
            
            type = [[[subString getInfomation:@"<div style=\"color:#555;\">.*?</div>"] getInfomation:@">.*?<"] mutableCopy];
            
            type = [type deleteString:@[@"<", @">", @" ", @"\n"]];
            
            
            donav = [[[subString getInfomation:@"DoNav.*?\""] getInfomation:@"'.*?'"] mutableCopy];
            donav = [[donav deleteString:@[@"'"]] mutableCopy];
            
            
            PlayerInfomation *player = [[PlayerInfomation alloc] init];
            player.name = name;
            player.icon = icon;
            player.type = type;
            player.donav = donav;
            [_dataArray addObject:player];
            
        }
        
        [_tableView.header endRefreshing];
        [_tableView reloadData];

    } failure:^(NSError *error) {
        HLAlertView *alertView = [[HLAlertView alloc] initWithtitle:@"检索不到玩家，请重新输入" target:self.view];
        [alertView show];
        [_tableView.header endRefreshing];
    } progress:^(NSProgress *progress) {
        
    }];
    
}

//- (void)clearBtnClick
//{
//    for (SearchList *list in [SearchList MR_findAll])
//    {
//        [list MR_deleteEntity];
//    }
//    [[NSManagedObjectContext MR_defaultContext] MR_saveToPersistentStoreAndWait];
//    [_dataArray removeAllObjects];
//    [_tableView reloadData];
//}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - TableViewDelegate
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _dataArray.count;
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if (_flag==1) {
        return 60;
    }
    return 0;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 60;
}

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    HLSearchTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"SearchCell"];
    if (!cell)
    {
        cell = [[[NSBundle mainBundle] loadNibNamed:@"HLSearchTableViewCell" owner:nil options:nil] lastObject];
    }
    
    PlayerInfomation *player = (PlayerInfomation *)_dataArray[indexPath.row];
    
    cell.name.text = player.name;
    cell.typeLabel.text = player.type;
    [cell.icon sd_setImageWithURL:[NSURL URLWithString:[player.icon stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]]];
    cell.backgroundColor=[UIColor clearColor];
    if (cell.icon.image.size.height == 0)
    {
        cell.icon.image = [UIImage imageNamed:@"wait.png"];
    }
    
    return cell;

}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    if (_flag == 1)
    {
        UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, WIDTH, 50)];
        view.backgroundColor = [UIColor clearColor];
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, WIDTH, 50)];
        label.text = @"输入玩家昵称便可查询相关信息";
        label.textAlignment=NSTextAlignmentCenter;
        [view addSubview:label];
        
        UIView *lineView = [[UIView alloc] init];
        lineView.frame = CGRectMake(0, 49, WIDTH, 1);
        lineView.backgroundColor = [UIColor blackColor];
        
        [view addSubview:lineView];
        
        return view;
    }
    else
    {
        return nil;
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
//    PlayerInfomation *playerModel = (PlayerInfomation*)_dataArray[indexPath.row];
//    
//    SearchList *model = [SearchList MR_createEntity];
//    
//    model.name = playerModel.name;
//    model.icon = playerModel.icon;
//    model.url = playerModel.donav;
//    model.type = playerModel.type;
    
//    [[NSManagedObjectContext MR_defaultContext] MR_saveToPersistentStoreAndWait];
    
    HLPlayerViewController *player = [[HLPlayerViewController alloc] init];
    player.url = [NSString stringWithFormat:@"http://www.lolmax.com%@", [_dataArray[indexPath.row] donav]];
    
    [[NSUserDefaults standardUserDefaults] setObject:[_dataArray[indexPath.row] donav] forKey:@"area_id"];
    [self presentViewController:player animated:YES completion:nil];
}



/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
