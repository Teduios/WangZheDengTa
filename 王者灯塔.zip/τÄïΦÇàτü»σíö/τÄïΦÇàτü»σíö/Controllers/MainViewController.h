//
//  MainViewController.h
//  王者灯塔
//
//  Created by tarena on 16/1/6.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MainViewController : UIViewController

+(UIViewController*)productViewController;

@end
