//
//  HeroItemDetailViewController.m
//  王者灯塔
//
//  Created by tarena on 16/1/25.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "HeroItemDetailViewController.h"
#import "ItemViewController.h"
#import "HLHeroAndProductTableViewCell.h"
#import "HeroInfomation.h"
#import "DrawLine.h"
#import "UIImageView+WebCache.h"
#import "AFNetworking.h"
#import "MJRefresh.h"
#import "HLNetModle.h"
#import "NSData+alalysisHtml.h"
#import "NSString+getInfomation.h"
#import "HLAlertView.h"


#define WIDTH [UIScreen mainScreen].bounds.size.width
#define HEIGHT [UIScreen mainScreen].bounds.size.height
#define ARRAY_SCROLLEVIEWTITLE @[@[@"物品", @"次数", @"胜率"], @[@"英雄", @"克制指数", @"次数"], @[@"英雄", @"配合指数", @"次数"]]

@interface HeroItemDetailViewController ()<UIScrollViewDelegate>

@property(nonatomic,strong)NSMutableArray *dataArray;
@property(nonatomic,strong)NSMutableArray *titleDataArray;
@property (nonatomic, assign) CGFloat maxWin;
@property(nonatomic,strong)UIButton* leftButton;

@end

@implementation HeroItemDetailViewController

{
    UIScrollView *_scrollView;
    DrawLine *_line;
    NSInteger _seletedTag;
    UIImageView *_titleIcon;
    UILabel *_titleNameLabel;
    UILabel *_titleSecondLabel;
    UILabel *_titleOtherLabel;
    NSMutableDictionary *_dataDict;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self createNavi];
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    [self createHeader];
    [self createScrollView];
    [self createTab];
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}

-(void)createTab
{
    UIView* view =[UIView new];
    view.frame=CGRectMake(0, HEIGHT-50, WIDTH, 150);
    UIImageView* imageView=[[UIImageView alloc]init];
    imageView.frame=CGRectMake(0, 0, WIDTH, 150);
    imageView.image=[UIImage imageNamed:@"tabbar2.png"];
    [view addSubview:imageView];
    [self.view addSubview:view];
}

-(void)createNavi
{
    UIView *view=[[UIView alloc]init];
    view.frame=CGRectMake(0, 20, WIDTH, 44);
    view.backgroundColor=[UIColor whiteColor];
    
    UIButton* button=[UIButton new];
    [button setImage:[UIImage imageNamed:@"navigationbar_back_highlighted@2x"] forState:UIControlStateHighlighted];
    [button setImage:[UIImage imageNamed:@"navigationbar_back@2x"] forState:UIControlStateNormal];
    [button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [button setTitleColor:[UIColor orangeColor] forState:UIControlStateHighlighted];
    button.titleLabel.font=[UIFont systemFontOfSize:16];
    button.frame=CGRectMake(15, 5, 30, 39);
    [button addTarget:self action:@selector(goBack) forControlEvents:UIControlEventTouchUpInside];
    
    UIButton* center=[UIButton new];
    [center setImage:[UIImage imageNamed:@"myLoc.png"] forState:0];
    center.userInteractionEnabled=NO;
    center.frame=CGRectMake(WIDTH/2-70, 5, 140, 40);
    
    [view addSubview:center];
    [view addSubview:button];
    [self.view addSubview:view];
}

-(void)goBack
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)titleBtnClick:(UIButton *)btn
{
    
    [_scrollView scrollRectToVisible:CGRectMake(_scrollView.contentOffset.x
                                                + WIDTH * (btn.tag - _seletedTag), 0, WIDTH, _scrollView.frame.size.height) animated:YES];
    _seletedTag = btn.tag;
}

-(void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    if (scrollView.tag == 2000)
    {
        _line.x = 50 + scrollView.contentOffset.x / 3;
        [_line setNeedsDisplay];
    }
    
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    if (scrollView.tag == 2000)
    {
        _seletedTag = 500 + scrollView.contentOffset.x / WIDTH;
    }
}

-(void)createHeader
{
    _titleIcon = [[UIImageView alloc] initWithFrame:CGRectMake(WIDTH / 3 - 80, 64 + 5, 80, 80)];
    _titleIcon.layer.cornerRadius = 40;
    _titleIcon.layer.masksToBounds = YES;
    _titleIcon.backgroundColor = [UIColor clearColor];
    
    _titleNameLabel = [[UILabel alloc] init];
    _titleSecondLabel = [[UILabel alloc] init];
    _titleOtherLabel = [[UILabel alloc] init];
    
    NSArray *array = @[_titleNameLabel, _titleSecondLabel, _titleOtherLabel];
    
    for (int i = 0; i < [array count]; i++)
    {
        UILabel *label = array[i];
        label.frame = CGRectMake(WIDTH / 3 + 10, 64 + 5 + 30 * i, WIDTH - (WIDTH / 3 + 10), 30);
        
        if (i == 0)
        {
            label.textColor = [UIColor blackColor];
            label.font = [UIFont boldSystemFontOfSize:20];
        }
        else
        {
            label.textColor = [UIColor blackColor];
            label.font = [UIFont systemFontOfSize:13];
        }
        
        [self.view addSubview:label];
    }
    
    [self.view addSubview:_titleIcon];
    
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, _titleOtherLabel.frame.origin.y + 35, WIDTH, 1)];
    view.backgroundColor = [UIColor lightGrayColor];
    view.alpha = 0.7;
    [self.view addSubview:view];
}

-(void)createScrollView
{
    NSArray *array = @[@"使用物品", @"克制英雄", @"配合英雄"];
    
    for (int i = 0; i < 3; i++)
    {
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        button.frame = CGRectMake(i * WIDTH / 3, 164, WIDTH / 3, 50);
        [button setTitle:array[i] forState:UIControlStateNormal];
        [button setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
        button.backgroundColor = [UIColor clearColor];
        button.tag = 500 + i;
        [button addTarget:self action:@selector(titleBtnClick:) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview:button];
    }
    
    _line = [[DrawLine alloc] initWithFrame:CGRectMake(0, 64, WIDTH, 140)];
    _line.x = 50;
    _line.backgroundColor = [UIColor lightGrayColor];
    [self.view addSubview:_line];
    [self.view sendSubviewToBack:_line];
    
    _scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 204, WIDTH, HEIGHT - 204 - 49)];
    _scrollView.contentSize = CGSizeMake(WIDTH * 3, HEIGHT - 204 - 64);
    _scrollView.delegate = self;
    _scrollView.backgroundColor = [UIColor clearColor];
    _scrollView.pagingEnabled = YES;
    _scrollView.bounces = NO;
    _scrollView.tag = 2000;
    _scrollView.scrollEnabled=NO;
    _scrollView.showsHorizontalScrollIndicator = NO;
    [self.view addSubview:_scrollView];
    
    for (int i = 0; i < 3; i++)
    {
        UIView *contentView = [self creatContentView:ARRAY_SCROLLEVIEWTITLE[i]];
        contentView.frame = CGRectMake(i * WIDTH, 0, WIDTH, HEIGHT - 204 - 64);
        
        UITableView *tableView = [[UITableView alloc] initWithFrame:CGRectMake(i * WIDTH, 31, WIDTH, HEIGHT - 204 - 49 - 31)];
        tableView.tag = 1000 + i;
        tableView.delegate = self;
        tableView.dataSource = self;
        tableView.header = [MJRefreshNormalHeader headerWithRefreshingTarget:self refreshingAction:@selector(headRefresh)];
        if (i == 0)
        {
            [tableView.header beginRefreshing];
        }
        
        [_scrollView addSubview:contentView];
        [_scrollView addSubview:tableView];
    }

}

- (void)headRefresh
{
    _titleDataArray = [[NSMutableArray alloc] init];
    _dataDict = [[NSMutableDictionary alloc] init];
    _dataArray = [[NSMutableArray alloc] init];
    [self getData:self.url];
}

-(void)getData:(NSString*) url
{
    [HLNetModle htmlGetHttpURL:url success:^(id Object) {
        NSString *titleIcon = [[NSData analysisHtml:Object ByString:@"<img src=\".*?\""][1] getInfomation:@"\".*?\""];
        [self.titleDataArray addObject:[titleIcon deleteString:@[@"\""]]];
        NSString *titleName = [[NSData analysisHtml:Object ByString:@"style=\"padding-top: 3px;\">.*?<"][0] getInfomation:@">.*?<"];
        [self.titleDataArray addObject:[titleName deleteString:@[@"<", @">", @" ", @"\n"]]];
        NSString *other = [[NSData analysisHtml:Object ByString:@"<span style=\"font-size:10px;.*?</"][0] getInfomation:@">.*?<"];
        [self.titleDataArray addObject:[[[other deleteString:@[@"<", @">", @" "]] componentsSeparatedByString:@"\n"] componentsJoinedByString:@" "]];
        NSString *times = [NSData analysisHtml:Object ByString:@"使用次数:.*?<"][0];
        NSString *win = [NSData analysisHtml:Object ByString:@"胜率:.*?<"][0];
        [self.titleDataArray addObject:[NSString stringWithFormat:@"%@,%@", [times deleteString:@[@" ", @"<"]], [win deleteString:@[@" ", @"<"]]]];
        
        [self refreshTitle];
        
        [self getTableData];
    } failure:^(NSError *error) {
        HLAlertView *alertView = [[HLAlertView alloc] initWithtitle:@"网络不好,请稍后重试" target:self.view];
        [alertView show];
    } progress:^(NSProgress *progress) {
        
    }];
}

-(void)refreshTitle
{
    [_titleIcon sd_setImageWithURL:[NSURL URLWithString:self.titleDataArray[0]]];
    _titleNameLabel.text = self.titleDataArray[1];
    _titleSecondLabel.text = self.titleDataArray[2];
    _titleOtherLabel.text = self.titleDataArray[3];
}

-(void)getTableData
{
    NSArray *array = @[@"item/", @"enemy/", @"teammates/"];
    NSMutableArray *urlArray = [[NSMutableArray alloc] init];
    for (int i = 0; i < 3; i++)
    {
        NSMutableArray * mArray = [[self.url componentsSeparatedByString:@"?"] mutableCopy];
        [mArray insertObject:array[i] atIndex:1];
        NSMutableString * mStr = [[mArray componentsJoinedByString:@"?"] mutableCopy];
        [mStr deleteCharactersInRange:[mStr rangeOfString:@"?"]];
        [urlArray addObject:mStr];
    }
    
    
    for (int i = 0; i < 3; i++)
    {
        [self beginRequest:i url:urlArray[i]];
    }
}

- (void)beginRequest:(NSInteger)flag url :(NSString *)url
{
    NSMutableArray *array = [[NSMutableArray alloc] init];
    [HLNetModle htmlGetHttpURL:url success:^(id Object) {
        NSArray *items = nil;
        if (flag == 0)
        {
            items = [NSData analysisHtml:Object ByString:@"item_detail.*?</tr>"];
        }
        else
        {
            items = [NSData analysisHtml:Object ByString:@"DoNav.*?</tr>"];
        }
        
        
        for (NSString *subString  in items)
        {
            
            NSMutableString *micon;
            NSMutableString *mname;
            NSMutableString *mtimes;
            NSMutableString *mwin;
            NSMutableString *mdonav;
            
            micon = [[[subString getInfomation:@"src=\".*?\""] getInfomation:@"\".*?\""] mutableCopy];
            micon = [micon deleteString:@[@"\""]];
            
            mname = [[[subString getInfomation:@"src=\".*?<"] getInfomation:@">.*?<"] mutableCopy];
            mname = [mname deleteString:@[@"\"", @" ", @">", @"<", @"\n"]];
            
            NSArray *subArray = [subString getInfomations:@"10px\">.*?</div>"];
            
            
            if (flag  == 0)
            {
                mtimes = [[subArray[0] getInfomation:@">.*?<"] mutableCopy];
                mtimes = [mtimes deleteString:@[@">", @"<"]];
                
                mwin = [[subArray[1] getInfomation:@">.*?<"] mutableCopy];
                mwin = [mwin deleteString:@[@">", @"<"]];
                mdonav = [[subString getInfomation:@"item.*?'"] mutableCopy];
                mdonav = [mdonav deleteString:@[@"'"]];
                [mdonav insertString:@"/" atIndex:0];
                
            }
            else
            {
                mtimes = [[subArray[2] getInfomation:@">.*?<"] mutableCopy];
                mtimes = [mtimes deleteString:@[@">", @"<"]];
                
                mwin = [[subArray[0] getInfomation:@">.*?<"] mutableCopy];
                mwin = [mwin deleteString:@[@">", @"<"]];
                
                mdonav = [[subString getInfomation:@"hero.*?'"] mutableCopy];
                mdonav = [mdonav deleteString:@[@"'"]];
                [mdonav insertString:@"/" atIndex:0];
                
            }
            
            HeroInfomation *item = [[HeroInfomation alloc] init];
            item.icon = micon;
            item.name = mname;
            item.times = mtimes;
            item.win = mwin;
            item.donav = mdonav;
            [array addObject:item];
        }
        
        if (flag != 0)
        {
            for (NSUInteger i = 0; i < [array count]; i++)
            {
                for (NSUInteger j = 0; j < [array count] - i - 1; j++)
                {
                    
                    if ([((HeroInfomation *)array[j]).win floatValue] < [((HeroInfomation *)array[j + 1]).win floatValue])
                    {
                        HeroInfomation *hero = [(HeroInfomation *)array[j] copy];
                        [array replaceObjectAtIndex:j withObject:array[j + 1]];
                        [array replaceObjectAtIndex:j + 1 withObject:hero];
                    }
                }
            }
            
            if ([((HeroInfomation *) array[0]).win floatValue] > -[((HeroInfomation *) array[[array count] - 1]).win floatValue])
            {
                self.maxWin = [((HeroInfomation *) array[0]).win floatValue];
            }
            else
            {
                self.maxWin = -[((HeroInfomation *) array[[array count] - 1]).win floatValue];
            }
        }
        
        [_dataDict setObject:array forKey:@(flag)];
        UITableView *tableView = (UITableView *)[self.view viewWithTag:1000 + flag];
        [tableView reloadData];
        [tableView.header endRefreshing];
        
    } failure:^(NSError *error) {
        HLAlertView *alertView = [[HLAlertView alloc] initWithtitle:@"网络不好,请稍后重试" target:self.view];
        [alertView show];
        UITableView *tableView = (UITableView *)[self.view viewWithTag:1000];
        [tableView.header endRefreshing];
    } progress:^(NSProgress *progress) {
        
    }];
}


- (UIView *)creatContentView:(NSArray *)titleArray
{
    UIView *view = [[UIView alloc] init];
    
    for (int i = 0; i < 3; i++)
    {
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(i * WIDTH / 3, 0, WIDTH / 3, 100)];
        label.text = titleArray[i];
        label.textColor = [UIColor blackColor];
        label.textAlignment = NSTextAlignmentCenter;
        label.font = [UIFont boldSystemFontOfSize:15];
        [view addSubview:label];
        
        UIView *lineview = [[UIView alloc] initWithFrame:CGRectMake(17 + i * WIDTH, 30, WIDTH - 17, 1)];
        lineview.backgroundColor = [UIColor lightGrayColor];
        lineview.alpha = 0.2;
        [_scrollView addSubview:lineview];
    }
    
    [self.view addSubview:view];
    
    return view;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 60;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (tableView.tag == 1000)
    {
        ItemViewController *item = [[ItemViewController alloc] init];
        item.url = [NSString stringWithFormat:@"http://www.lolmax.com%@", ((HeroInfomation *)_dataDict[@(tableView.tag - 1000)][indexPath.row]).donav];
        [self presentViewController:item animated:YES completion:nil];
    }
    else
    {
        HeroItemDetailViewController *detail = [[HeroItemDetailViewController alloc] init];
        detail.url = [NSString stringWithFormat:@"http://www.lolmax.com%@", ((HeroInfomation *)_dataDict[@(tableView.tag - 1000)][indexPath.row]).donav];
        [self presentViewController:detail animated:YES completion:nil];
    }

}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    return [_dataDict[@(tableView.tag - 1000)] count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    HLHeroAndProductTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"HeroAndItemCell"];
    if (!cell) {
        cell=[[NSBundle mainBundle] loadNibNamed:@"HLHeroAndProductTableViewCell" owner:nil options:nil].lastObject;
    }
    HeroInfomation *hero = (HeroInfomation *)_dataDict[@(tableView.tag - 1000)][indexPath.row];
    
    [cell.iconView sd_setImageWithURL:[NSURL URLWithString:hero.icon]];
    cell.nameLable.text = hero.name;
    cell.timesLable.text = hero.times;
    cell.winLable.text = hero.win;
    CGFloat progress = [hero.win floatValue];
    
    if (tableView.tag == 1000)
    {
        cell.winProgress.progress = progress / 100.0;
        
        cell.winLable.frame = CGRectMake(WIDTH * 2 / 3, 15, WIDTH / 3, 20);
        
        cell.timesLable.frame = CGRectMake(WIDTH / 3, 5, WIDTH / 3, 40);
        cell.winProgress.frame = CGRectMake(WIDTH * 2 / 3 + 5, 35, WIDTH / 3 - 10, 20);
    }
    else
    {
        if (progress < 0)
        {
            cell.winProgress.progressTintColor = [UIColor redColor];
            progress *= -1;
            
            cell.winProgress.progress = progress / self.maxWin;
            NSLog(@"%f", self.maxWin);
        }
        else
        {
            cell.winProgress.progressTintColor = [UIColor blackColor];
            
            cell.winProgress.progress = progress / self.maxWin;
            NSLog(@"%f", self.maxWin);
        }
        
        
    }
    
    cell.backgroundColor = [UIColor clearColor];
    return cell;
}



/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
