//
//  HLPlayerViewController.m
//  王者灯塔
//
//  Created by tarena on 16/1/27.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "HLPlayerViewController.h"
#import "DrawLine.h"
#import "PlayerInfomation.h"
#import "HeroInfomation.h"
#import "HLNetModle.h"
#import "NSData+alalysisHtml.h"
#import "MJRefresh.h"
#import "NSString+getInfomation.h"
#import "UIImageView+WebCache.h"
#import "BaseCell.h"
#import "SearchViewController.h"
#import "HLAlertView.h"

#define WIDTH [UIScreen mainScreen].bounds.size.width
#define HEIGHT [UIScreen mainScreen].bounds.size.height
#define ARRAY_PLAYER_TITLE @[@[@"英雄", @"使用次数", @"胜率", @"MVP次数"], @[@"英雄", @"时间", @"结果", @"KDA"], @[@"英雄", @"结果", @"类型", @"记录"]]

@interface HLPlayerViewController ()

@property (nonatomic, strong) NSMutableArray *titleDataArray;

@end

@implementation HLPlayerViewController

{
    UIImageView *_titleIcon;
    UILabel *_titleNameLabel;
    UILabel *_titleSecondLabel;
    UILabel *_titleOtherLabel;
    DrawLine *_line;
    UIScrollView *_scrollView;
    UIScrollView *_subScrollView;
    NSInteger _seletedTag;
    NSMutableArray *_subDataArray;
    NSMutableArray *_killArray;
    NSMutableArray *_heroDataArray;
    NSMutableArray *_matchDataArray;
    NSMutableArray *_maxDataArray;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    [self createTab];
    [self createNavi];
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
    if (self.url.length == 0)
    {
        [self getUserInfo];
     
    }
    else
        
    {
        
        [self creatHeader];
        [self creatScrollView];
    }

}

- (void)getUserInfo
{
    NSString *url = [[NSUserDefaults standardUserDefaults] objectForKey:@"area_id"];
    if (url==nil) {
    [HLNetModle apiGetHttpURL:[@"http://api.maxjia.com/api/account/login/?phone_num=13269020311&pwd=5667030zkw" stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding] success:^(id Object) {
        NSString *areaID = [NSString stringWithFormat:@"%@", Object[@"result"][@"lol_id_info"][@"area_id"]];
        NSString *uid = Object[@"result"][@"lol_id_info"][@"uid"];
        
        if (areaID.length > 0 && uid.length > 0)
        {
            self.url = [NSString stringWithFormat:@"http://www.lolmax.com/player/detail/?area_id=%@&id=%@", areaID, uid];
        }
        
        [self creatHeader];
        [self creatScrollView];
        } failure:^(NSError *error) {
        
        } progress:^(NSProgress *progress) {
        
        }];
    }else{
        self.url = [NSString stringWithFormat:@"http://www.lolmax.com%@", url];
        [self creatHeader];
        
        [self creatScrollView];
    }

}


-(void)creatHeader
{
    _seletedTag = 500;
    
    _titleIcon = [[UIImageView alloc] initWithFrame:CGRectMake(WIDTH / 3 - 80, 64 + 5, 80, 80)];
    _titleIcon.layer.cornerRadius = 40;
    _titleIcon.layer.masksToBounds = YES;
    _titleIcon.backgroundColor = [UIColor clearColor];
    
    _titleNameLabel = [[UILabel alloc] init];
    _titleSecondLabel = [[UILabel alloc] init];
    _titleOtherLabel = [[UILabel alloc] init];
    
    NSArray *array = @[_titleNameLabel, _titleSecondLabel, _titleOtherLabel];
    
    for (int i = 0; i < [array count]; i++)
    {
        UILabel *label = array[i];
        label.frame = CGRectMake(WIDTH / 3 + 10, 64 + 5 + 30 * i, WIDTH - (WIDTH / 3 + 10), 30);
        
        if (i == 0)
        {
            label.textColor = [UIColor blackColor];
            label.font = [UIFont boldSystemFontOfSize:20];
        }
        else
        {
            label.textColor = [UIColor blackColor];
            label.font = [UIFont systemFontOfSize:13];
        }
        
        [self.view addSubview:label];
    }
    
    [self.view addSubview:_titleIcon];
    
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, _titleOtherLabel.frame.origin.y + 35, WIDTH, 1)];
    view.backgroundColor = [UIColor lightGrayColor];
    view.alpha = 0.7;
    [self.view addSubview:view];
}

-(void)creatScrollView
{
    NSArray *array = @[@"综合统计", @"英雄统计", @"比赛统计", @"最高统计"];
    
    for (int i = 0; i < 4; i++)
    {
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        button.frame = CGRectMake(i * WIDTH / 4, 164, WIDTH / 4, 30);
        [button setTitle:array[i] forState:UIControlStateNormal];
        [button setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
        button.backgroundColor = [UIColor clearColor];
        button.tag = 500 + i;
        [button addTarget:self action:@selector(titleBtnClick:) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview:button];
    }
    
    _line = [[DrawLine alloc] initWithFrame:CGRectMake(0, 64, WIDTH, 140)];
    _line.x = 40;
    _line.backgroundColor = [UIColor lightGrayColor];
    [self.view addSubview:_line];
    [self.view sendSubviewToBack:_line];
    
    _scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 204, WIDTH, HEIGHT - 204 - 49)];
    _scrollView.contentSize = CGSizeMake(WIDTH * 4, HEIGHT - 204 - 64);
    _scrollView.delegate = self;
    _scrollView.backgroundColor = [UIColor clearColor];
    _scrollView.pagingEnabled = YES;
    _scrollView.bounces = NO;
    _scrollView.tag = 2000;
    _scrollView.showsHorizontalScrollIndicator = NO;
    [self.view addSubview:_scrollView];
    
    for (int i = 0; i < 4; i++)
    {
        if (i == 0)
        {
            [self creatSubScrollView];
        }
        
        else
        {
            
            for (int j = 0; j < 4; j++)
            {
                UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(WIDTH * i + j * WIDTH / 4, 0, WIDTH / 4, 30)];
                label.textAlignment = NSTextAlignmentCenter;
                label.backgroundColor = [UIColor whiteColor];
                label.textColor = [UIColor blackColor];
                
                label.text = ARRAY_PLAYER_TITLE[i - 1][j];
                
                [_scrollView addSubview:label];
            }
            
            UIView *view = [[UIView alloc] initWithFrame:CGRectMake(WIDTH * i + 16, 30, WIDTH - 16, 1)];
            view.backgroundColor = [UIColor lightGrayColor];
            view.alpha = 0.7;
            [_scrollView addSubview:view];
            
            UITableView *tableView = [[UITableView alloc] initWithFrame:CGRectMake(i * WIDTH, 31, WIDTH, HEIGHT - 204 - 49 - 31)];
            tableView.tag = 1000 + i - 1;
            
            tableView.delegate = self;
            tableView.dataSource = self;
            tableView.tableFooterView = [[UIView alloc] init];
            [_scrollView addSubview:tableView];
            
        }
    }

}

-(void)headRefresh
{
    _subDataArray = [[NSMutableArray alloc] init];
    self.titleDataArray = [[NSMutableArray alloc] init];
    _killArray = [[NSMutableArray alloc] init];
    _heroDataArray = [[NSMutableArray alloc] init];
    _matchDataArray = [[NSMutableArray alloc] init];
    _maxDataArray = [[NSMutableArray alloc] init];
    [self getHeadData:self.url];
    [self getTableViewData];
}

-(void)getHeadData:(NSString *)url
{
    [HLNetModle htmlGetHttpURL:[url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding] success:^(id Object) {
        [_subScrollView.header endRefreshing];
        
        NSString *titleIcon = [[NSData analysisHtml:Object ByString:@"<img src=\".*?\""][1] getInfomation:@"\".*?\""];
        [self.titleDataArray addObject:[titleIcon deleteString:@[@"\""]]];
        NSString *titleName = [[NSData analysisHtml:Object ByString:@"<span style=\"font-size:16px;font-weight: bold;.*?</span>"][0] getInfomation:@">.*?<"];
        
        [self.titleDataArray addObject:[titleName deleteString:@[@"<", @">", @" ", @"\n"]]];
        NSString *other = [[NSData analysisHtml:Object ByString:@"<div class=\"player-stats\">.*?</div>"][0] getInfomation:@">.*?<"];
        [self.titleDataArray addObject:[[[other deleteString:@[@"<", @">", @" "]] componentsSeparatedByString:@"\n"] componentsJoinedByString:@" "]];
        NSString *other1 = [[NSData analysisHtml:Object ByString:@"<div class=\"player-stats\" style=\"color: #efba6b;\">.*?</div>"][0] getInfomation:@">.*?<"];
        [self.titleDataArray addObject:[[[other1 deleteString:@[@"<", @">", @" "]] componentsSeparatedByString:@"\n"] componentsJoinedByString:@" "]];
        
        NSArray *killArray = [NSData analysisHtml:Object ByString:@"<div class=\"player-stats\">.*?</div>"];
        
        for (int i = 0; i < [killArray count]; i++)
        {
            NSMutableString *str = [[killArray[i] getInfomation:@">.*?<"] mutableCopy];
            str = [str deleteString:@[@"<", @">", @" "]];
            [_killArray addObject:str];
            
            if (i == 2)
            {
                str = [[NSData analysisHtml:Object ByString:@"<div class=\"player-stats\" style=\"\">.*?</div>"][0] mutableCopy];
                str = [[killArray[i] getInfomation:@">.*?<"] mutableCopy];
                str = [str deleteString:@[@"<", @">", @" "]];
                [_killArray addObject:str];
                
                
            }
        }
        
        NSString *str = [NSData analysisHtml:Object ByString:@"<tbody>.*?</tbody>"][0];
        NSArray *array = [str getInfomations:@"<tr>.*?</tr>"];
        
        NSArray *maxArray = [[NSData analysisHtml:Object ByString:@"<tbody>.*?</tbody>"][1] getInfomations:@"<div style=\"width: 200px;float: left;\">.*?</div>"];
        
        for (int i = 0; i < [maxArray count]; i++)
        {
            NSMutableString *str = [[maxArray[i] getInfomation:@">(.*?)<"] mutableCopy];
            
            str = [str deleteString:@[@"<", @">", @" " , @"\n"]];
            
            [_killArray addObject:str];
        }
        
        [_killArray removeObjectAtIndex:0];
        
        NSArray *iconArray = [NSData analysisHtml:Object ByString:@"<div class=\"player-stats\" style=\"margin-top: -10px;\">.*?</div>"];
        
        if (iconArray.count > 0)
        {
            NSMutableString *icon = [[NSString stringWithFormat:@"http://www.lolmax.com%@", [iconArray[0] getInfomation:@"/.*? "]] mutableCopy];
            
            if (icon.length > 0)
            {
                icon = [icon deleteString:@[@" ", @"\n"]];
                [_killArray addObject:icon];
                
                
                NSMutableString *score = [[[NSData analysisHtml:Object ByString:@"<div style=\"font-size: 12px;font-weight: 500;margin-bottom: 4px;color:#999;margin-top: 10px;\">.*?</div>"][2] getInfomation:@">.*?<"] mutableCopy];
                score = [score deleteString:@[@">", @"<"]];
                [_killArray addObject:score];
            }
            
            
        }
        
        [self refreshTitle];
        
        for (int i = 0; i < [array count]; i++)
        {
            NSMutableString *type = nil;
            NSMutableString *times = nil;
            NSMutableString *win = nil;
            NSMutableString *escape = nil;
            
            type = [[[array[i] getInfomation:@"<div style=\"line-height: 30px;float:left;\">.*?</div>"] getInfomation:@">.*?<"] mutableCopy];
            type = [type deleteString:@[@">", @"<", @" ", @"\n"]];
            
            times = [[[array[i] getInfomations:@"<div style=\"height: 10px\">(.*?)</div>"][0] getInfomation:@">.*?<"] mutableCopy];
            times = [times deleteString:@[@">", @"<", @" ", @"\n"]];
            
            win = [[[array[i] getInfomations:@"<div style=\"height: 10px\">(.*?)</div>"][1] getInfomation:@">.*?<"] mutableCopy];
            win = [win deleteString:@[@">", @"<", @" ", @"\n"]];
            
            escape = [[[array[i] getInfomation:@"<td style=\"line-height: 30px;\">.*?</td>"] getInfomation:@">.*?<"] mutableCopy];
            escape = [escape deleteString:@[@">", @"<", @" ", @"\n"]];
            
            PlayerInfomation *player = [[PlayerInfomation alloc] init];
            player.type = type;
            
            player.score = times;
            player.win = win;
            player.escape = escape;
            
            [_subDataArray addObject:player];
        }
        
        UITableView *tableView = (UITableView *)[self.view viewWithTag:1003];
        [tableView reloadData];
        
        
        maxArray = [NSData analysisHtml:Object ByString:@"<table class=\"table table-hover table-striped table-list table-thead-left\" style=\"width: 710px; margin-left: 2px;float: left;margin-bottom: 40px;\">.*?</table>"];
        
        array = [maxArray[0] getInfomations:@"DoNav.*?</tr>"];
        
        
        NSMutableString *ico;
        NSMutableString *name;
        NSMutableString *win;
        NSMutableString *times;
        NSMutableString *donav;
        NSMutableString *mvpCount;
        
        for (NSString *subString in array)
        {
            ico = [[[subString getInfomation:@"src=\".*?\""] getInfomation:@"\".*?\""] mutableCopy];
            NSRange range;
            
            while ((range = [ico rangeOfString:@"\""]).location != NSNotFound)
            {
                [ico deleteCharactersInRange:range];
            }
            
            name = [[[subString getInfomation:@"<div style=\"float:left;margin-top: 5px;margin-left: 5px;\">(.*?)<br>"] getInfomation:@">.*?<"] mutableCopy];
            
            name = [name deleteString:@[@"<", @">", @" ", @"\n", @"\""]];
            
            NSArray *subArray = [subString getInfomations:@"<span.*?<"];
            win = [[subArray[1] getInfomation:@">.*?<"] mutableCopy];
            win = [win deleteString:@[@"<", @">", @" ", @"\n"]];
            times = [[[[subString getInfomation:@"<td>.*?</td><td>.*?</td><td>.*?</td><td style"] getInfomations:@"<td>.*?</td>"][4] getInfomation:@">.*?<"] mutableCopy];
            times = [times deleteString:@[@"<", @">", @" ", @"\n"]];
            
            
            mvpCount = [[[subString getInfomation:@"<td style=\"font-weight: 700;color:#ccc;font-size: 14px;\">.*?</td>"] getInfomation:@">.*?<"] mutableCopy];
            mvpCount = [mvpCount deleteString:@[@"<", @">", @" ", @"\n"]];
            
            
            
            
            donav = [[[subString getInfomation:@"DoNav.*?\""] getInfomation:@"'.*?'"] mutableCopy];
            donav = [[donav deleteString:@[@"'"]] mutableCopy];
            
            HeroInfomation *hero = [[HeroInfomation alloc] init];
            hero.name = name;
            hero.icon = ico;
            hero.win = win;
            hero.times = times;
            hero.donav = donav;
            hero.mvpCount = mvpCount;
            
            [_maxDataArray addObject:hero];
        }
        
        tableView = (UITableView *)[self.view viewWithTag:1002];
        [tableView reloadData];

    } failure:^(NSError *error) {
         [_subScrollView.header endRefreshing];
        HLAlertView *alertView = [[HLAlertView alloc] initWithtitle:@"网络不好,请稍后重试" target:self.view];
        [alertView show];
    } progress:^(NSProgress *progress) {
        
    }];
}

-(void)getTableViewData
{
    NSMutableArray *urlArray = [[self.url componentsSeparatedByString:@"?"] mutableCopy];
    [urlArray insertObject:@"hero/" atIndex:1];
    
    NSMutableString *url = [[urlArray componentsJoinedByString:@"?"] mutableCopy];
    [url deleteCharactersInRange:[url rangeOfString:@"?"]];
    [HLNetModle htmlGetHttpURL:[url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding] success:^(id Object) {
        NSArray *array = [NSData analysisHtml:Object ByString:@"DoNav.*?</tr>"];
        NSMutableString *icon;
        NSMutableString *name;
        NSMutableString *win;
        NSMutableString *times;
        NSMutableString *donav;
        NSMutableString *mvpCount;
        
        for (NSString *subString in array)
        {
            icon = [[[subString getInfomation:@"src=\".*?\""] getInfomation:@"\".*?\""] mutableCopy];
            NSRange range;
            
            while ((range = [icon rangeOfString:@"\""]).location != NSNotFound)
            {
                [icon deleteCharactersInRange:range];
            }
            
            name = [[[subString getInfomation:@"</img(.*?)</td>"] getInfomation:@">.*?<"] mutableCopy];
            
            [name deleteCharactersInRange:[name rangeOfString:@">"]];
            [name deleteCharactersInRange:[name rangeOfString:@"<"]];
            
            while ((range = [name rangeOfString:@" "]).location != NSNotFound || (range = [name rangeOfString:@"\n"]).location != NSNotFound)
            {
                [name deleteCharactersInRange:range];
            }
            NSArray *subArray = [subString getInfomations:@"style=\"height: 10px\".*?<"];
            win = [[subArray[0] getInfomation:@">.*?<"] mutableCopy];
            [win deleteCharactersInRange:[win rangeOfString:@">"]];
            [win deleteCharactersInRange:[win rangeOfString:@"<"]];
            times = [[subArray[1] getInfomation:@">.*?<"] mutableCopy];
            [times deleteCharactersInRange:[times rangeOfString:@">"]];
            [times deleteCharactersInRange:[times rangeOfString:@"<"]];
            
            mvpCount = [[subArray[2] getInfomation:@">.*?<"] mutableCopy];
            [mvpCount deleteCharactersInRange:[mvpCount rangeOfString:@">"]];
            [mvpCount deleteCharactersInRange:[mvpCount rangeOfString:@"<"]];
            
            
            donav = [[[subString getInfomation:@"DoNav.*?\""] getInfomation:@"'.*?'"] mutableCopy];
            donav = [[donav deleteString:@[@"'"]] mutableCopy];
            
            HeroInfomation *hero = [[HeroInfomation alloc] init];
            hero.name = name;
            hero.icon = icon;
            hero.win = win;
            hero.times = times;
            hero.donav = donav;
            hero.mvpCount = mvpCount;
            
            [_heroDataArray addObject:hero];
        }
        
        UITableView *tableView = (UITableView *)[_scrollView viewWithTag:1000];
        [tableView reloadData];

    } failure:^(NSError *error) {
        NSLog(@"%@", error);
        
    } progress:^(NSProgress *progress) {
        
    }];
    
    urlArray = [[self.url componentsSeparatedByString:@"?"] mutableCopy];
    [urlArray insertObject:@"match/" atIndex:1];
    
    url = [[urlArray componentsJoinedByString:@"?"] mutableCopy];
    [url deleteCharactersInRange:[url rangeOfString:@"?"]];
    [HLNetModle htmlGetHttpURL:[url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding] success:^(id Object) {
        NSArray *array = [NSData analysisHtml:Object ByString:@"DoNav.*?</tr>"];
        
        NSMutableString *icon;
        NSMutableString *name;
        NSMutableString *win;
        NSMutableString *times;
        NSMutableString *donav;
        NSMutableString *mvpCount;
        
        for (NSString *subString in array)
        {
            icon = [[[subString getInfomation:@"src=\".*?\""] getInfomation:@"\".*?\""] mutableCopy];
            NSRange range;
            
            while ((range = [icon rangeOfString:@"\""]).location != NSNotFound)
            {
                [icon deleteCharactersInRange:range];
            }
            
            name = [[[subString getInfomation:@"</img(.*?)</td>"] getInfomation:@">.*?<"] mutableCopy];
            
            [name deleteCharactersInRange:[name rangeOfString:@">"]];
            [name deleteCharactersInRange:[name rangeOfString:@"<"]];
            
            while ((range = [name rangeOfString:@" "]).location != NSNotFound || (range = [name rangeOfString:@"\n"]).location != NSNotFound)
            {
                [name deleteCharactersInRange:range];
            }
            NSArray *subArray = [subString getInfomations:@"<span.*?<"];
            win = [[subArray[0] getInfomation:@">.*?<"] mutableCopy];
            win = [win deleteString:@[@"<", @">", @" ", @"\n"]];
            times = [[[[subString getInfomation:@"</div></td><td>.*?<"] getInfomation:@"<td>.*?<"] getInfomation:@">.*?<"] mutableCopy];
            times = [times deleteString:@[@"<", @">", @" ", @"\n"]];
            
            mvpCount = [[[subString getInfomation:@"<div style=\"float: left;width: 17%;line-height: 40px;font-size: 14px;font-weight: 700;margin-left: 3%;\">.*?</div>"] getInfomation:@">.*?<"] mutableCopy];
            mvpCount = [mvpCount deleteString:@[@"<", @">", @" ", @"\n"]];
            
            NSMutableString *mStr = [[[subString getInfomation:@"<div style=\"height: 12px;margin-top: 7px;\">.*?</div>"] getInfomation:@">.*?<"] mutableCopy];
            
            mStr = [mStr deleteString:@[@"<", @">", @" ", @"\n"]];
            [mvpCount appendFormat:@"(%@)", mStr];
            
            donav = [[[subString getInfomation:@"DoNav.*?\""] getInfomation:@"'.*?'"] mutableCopy];
            donav = [[donav deleteString:@[@"'"]] mutableCopy];
            
            HeroInfomation *hero = [[HeroInfomation alloc] init];
            hero.name = name;
            hero.icon = icon;
            hero.win = win;
            hero.times = times;
            hero.donav = donav;
            hero.mvpCount = mvpCount;
            
            [_matchDataArray addObject:hero];
        }
        
        UITableView *tableView = (UITableView *)[_scrollView viewWithTag:1000];
        [tableView reloadData];
        tableView = (UITableView *)[_scrollView viewWithTag:1001];
        [tableView reloadData];
    } failure:^(NSError *error) {
        HLAlertView *alertView = [[HLAlertView alloc] initWithtitle:@"网络不好,请稍后重试" target:self.view];
        [alertView show];
        NSLog(@"%@", error);
    } progress:^(NSProgress *progress) {
   
    }];
    
    
}

-(void)refreshTitle
{
    [_titleIcon sd_setImageWithURL:[NSURL URLWithString:self.titleDataArray[0]]];
    _titleNameLabel.text = self.titleDataArray[1];
    _titleSecondLabel.text = [NSString stringWithFormat:@"胜点:%@", self.titleDataArray[2]];
    _titleOtherLabel.text = [NSString stringWithFormat:@"隐藏分:%@", self.titleDataArray[3]];
    
    for (int i = 0; i < 4; i++)
    {
        UILabel *label = (UILabel *)[self.view viewWithTag:5 + i];
        label.text = _killArray[3 - i];
    }
    
    UILabel *label = (UILabel *)[self.view viewWithTag:9];
    label.text = [NSString stringWithFormat:@"   %@", _killArray[4]];
    
    label = (UILabel *)[self.view viewWithTag:10];
    label.text = [NSString stringWithFormat:@"   %@", _killArray[5]];
    
    if ([_killArray count] > 6)
    {
        UIImageView *imageView = (UIImageView *)[self.view viewWithTag:200];
        [imageView sd_setImageWithURL:[NSURL URLWithString:[_killArray[6] stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]]];
        
        UILabel *label = (UILabel *)[self.view viewWithTag:300];
        label.text = _killArray[7];
    }

}

-(void)creatSubScrollView
{
    _subScrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, WIDTH, _scrollView.frame.size.height)];
    
    for (int i = 0; i < 2; i++)
    {
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, 15 + i * 30, WIDTH, 30)];
        label.tag = 9 + i;
        label.backgroundColor = [UIColor lightGrayColor];
        label.font = [UIFont boldSystemFontOfSize:15];
        label.textColor = [UIColor blackColor];
        [_subScrollView addSubview:label];
    }
    
    UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(WIDTH - 80, 10, 50, 50)];
    imageView.tag = 200;
    UILabel *gragelabel = [[UILabel alloc] initWithFrame:CGRectMake(WIDTH - 90, 58, 80, 15)];
    gragelabel.textAlignment = NSTextAlignmentCenter;
    gragelabel.backgroundColor = [UIColor clearColor];
    gragelabel.font = [UIFont boldSystemFontOfSize:15];
    gragelabel.textColor = [UIColor blackColor];
    gragelabel.tag = 300;
    [_subScrollView addSubview:imageView];
    [_subScrollView addSubview:gragelabel];
    
    NSArray *array = @[@"三杀", @"四杀", @"五杀", @"超神"];
    
    for (int i = 0; i < 4; i++)
    {
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(i * WIDTH / 4, 80, WIDTH / 4, 30)];
        label.text = array[i];
        label.textAlignment = NSTextAlignmentCenter;
        label.backgroundColor = [UIColor clearColor];
        label.font = [UIFont boldSystemFontOfSize:20];
        label.textColor = [UIColor lightGrayColor];
        [_subScrollView addSubview:label];
        
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        button.frame = CGRectMake(i * WIDTH / 4, 110, WIDTH / 4, 50);
        [button setImage:[UIImage imageNamed:@"btn_kill"] forState:UIControlStateNormal];
        
        UILabel *btnLabel = [[UILabel alloc] initWithFrame:CGRectMake(i * WIDTH / 4, 110, WIDTH / 4, 50)];
        btnLabel.textAlignment = NSTextAlignmentCenter;
        btnLabel.backgroundColor = [UIColor clearColor];
        btnLabel.textColor = [UIColor blackColor];
        btnLabel.tag = 5 + i;
        [_subScrollView addSubview:button];
        [_subScrollView addSubview:btnLabel];
    }
    
    UITableView *tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 170, WIDTH, 300)];
    tableView.tag = 1003;
    tableView.delegate = self;
    tableView.dataSource = self;
    tableView.tableFooterView = [[UIView alloc] init];
    [_subScrollView addSubview:tableView];
    _subScrollView.header = [MJRefreshNormalHeader headerWithRefreshingTarget:self refreshingAction:@selector(headRefresh)];
    [_subScrollView.header beginRefreshing];
    [_scrollView addSubview:_subScrollView];
    
    _subScrollView.contentSize = CGSizeMake(WIDTH, 500);

}

-(void)createTab
{
    UIView* view =[UIView new];
    view.frame=CGRectMake(0, HEIGHT-50, WIDTH, 150);
    UIImageView* imageView=[[UIImageView alloc]init];
    imageView.frame=CGRectMake(0, 0, WIDTH, 150);
    imageView.image=[UIImage imageNamed:@"tabbar2.jpg"];
    [view addSubview:imageView];
    [self.view addSubview:view];
}

-(void)createNavi
{
    UIView *view=[[UIView alloc]init];
    view.frame=CGRectMake(0, 20, WIDTH, 44);
    view.backgroundColor=[UIColor whiteColor];
    
    UIButton* button=[UIButton new];
    [button setImage:[UIImage imageNamed:@"navigationbar_back_highlighted@2x"] forState:UIControlStateHighlighted];
    [button setImage:[UIImage imageNamed:@"navigationbar_back@2x"] forState:UIControlStateNormal];
    [button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [button setTitleColor:[UIColor orangeColor] forState:UIControlStateHighlighted];
    button.titleLabel.font=[UIFont systemFontOfSize:16];
    button.frame=CGRectMake(15, 5, 30, 39);
    [button addTarget:self action:@selector(goBack) forControlEvents:UIControlEventTouchUpInside];
    
    UIButton* center=[UIButton new];
    [center setImage:[UIImage imageNamed:@"myLoc.png"] forState:0];
    center.userInteractionEnabled=NO;
    center.frame=CGRectMake(WIDTH/2-70, 5, 140, 40);
    
    [view addSubview:center];
    [view addSubview:button];
    [self.view addSubview:view];
}

-(void)goBack
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)titleBtnClick:(UIButton *)btn
{
    
    [_scrollView scrollRectToVisible:CGRectMake(_scrollView.contentOffset.x
                                                + WIDTH * (btn.tag - _seletedTag), 0, WIDTH, _scrollView.frame.size.height) animated:YES];
    _seletedTag = btn.tag;
}

-(void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    if (scrollView.tag == 2000)
    {
        _line.x = 40 + scrollView.contentOffset.x / 4;
        [_line setNeedsDisplay];
    }
    
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    if (scrollView.tag == 2000)
    {
        _seletedTag = 500 + scrollView.contentOffset.x / WIDTH;
    }
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, WIDTH, 40)];
    
    if (tableView.tag == 1003)
    {
        NSArray *array = @[@"类型", @"次数", @"胜率", @"逃跑"];
        
        for (int i = 0; i < [array count]; i++)
        {
            UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(i * WIDTH / 4, 0, WIDTH / 4, 40)];
            label.text = array[i];
            label.textColor = [UIColor blackColor];
            label.backgroundColor = [UIColor lightGrayColor];
            label.textAlignment = NSTextAlignmentCenter;
            [view addSubview:label];
        }
        
        return view;
    }
    
    return nil;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    if (tableView.tag == 1000)
    {
        return [_heroDataArray count];
    }
    else if (tableView.tag == 1001)
    {
        return [_matchDataArray count];
        
    }
    else if (tableView.tag == 1002)
    {
        return [_maxDataArray count];
    }
    return [_subDataArray count];
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if (tableView.tag == 1003)
    {
        return 50;
    }
    return 0;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 60;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    BaseCell *cell = [tableView dequeueReusableCellWithIdentifier:@"rootcell"];
    
    if (!cell)
    {
        cell = [[[NSBundle mainBundle] loadNibNamed:@"BaseCell" owner:nil options:nil] lastObject];
    }
    
    if (tableView.tag == 1000)
    {
        HeroInfomation *hero = _heroDataArray[indexPath.row];
        cell.nameLabel.text = hero.name;
        [cell.icon sd_setImageWithURL:[NSURL URLWithString:[hero.icon stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]]];
        cell.nameLabel.hidden = NO;
        cell.icon.hidden = NO;
        cell.secondLable.text = hero.win;
        cell.thirdLable.text = hero.times;
        cell.forthLable.text = hero.mvpCount;
        
    }
    else if (tableView.tag == 1001)
    {
        HeroInfomation *hero = _matchDataArray[indexPath.row];
        cell.nameLabel.text = hero.name;
        [cell.icon sd_setImageWithURL:[NSURL URLWithString:[hero.icon stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]]];
        cell.nameLabel.hidden = NO;
        cell.icon.hidden = NO;
        cell.secondLable.text = hero.times;
        cell.thirdLable.text = hero.win;
        
        if ([hero.win isEqualToString:@"失败"])
        {
            cell.backgroundColor = [UIColor lightGrayColor];
        }
        
        cell.forthLable.text = hero.mvpCount;
        cell.forthLable.textAlignment = NSTextAlignmentLeft;
    }
    else if (tableView.tag == 1002)
    {
        HeroInfomation *hero = _maxDataArray[indexPath.row];
        cell.nameLabel.text = hero.name;
        [cell.icon sd_setImageWithURL:[NSURL URLWithString:[hero.icon stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]]];
        cell.nameLabel.hidden = NO;
        cell.icon.hidden = NO;
        cell.secondLable.text = hero.win;
        cell.thirdLable.text = hero.times;
        cell.thirdLable.font = [UIFont systemFontOfSize:13];
        if ([hero.win isEqualToString:@"失败"])
        {
            cell.backgroundColor = [UIColor lightGrayColor];
        }
        
        cell.forthLable.text = hero.mvpCount;
    }
    else
    {
        PlayerInfomation *player = _subDataArray[indexPath.row];
        
        cell.firstLable.text = player.type;
        cell.secondLable.text = player.score;
        cell.thirdLable.text = player.win;
        cell.forthLable.text = player.escape;
        
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    return cell;

}


/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
