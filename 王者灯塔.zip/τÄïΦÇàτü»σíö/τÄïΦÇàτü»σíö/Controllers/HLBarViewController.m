//
//  HLBarViewController.m
//  王者灯塔
//
//  Created by tarena on 16/1/4.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "HLBarViewController.h"
#import "HLCenterBar.h"
#import "MainViewController.h"

@interface HLBarViewController ()<HLCenterBarDelegate>
@property(nonatomic,strong)UIViewController* viewController;
@end

@implementation HLBarViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    for (UIViewController *vc in self.viewControllers) {
        //读取设置过的选中图片,修改渲染模式为本来样式
        UIImage *selectedImage = [vc.tabBarItem.selectedImage imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
        vc.tabBarItem.selectedImage = selectedImage;
        
        UITabBarItem *barItem = vc.tabBarItem;
        [barItem setTitlePositionAdjustment:UIOffsetMake(0, -1)];
        
        NSMutableDictionary *normalAttributes = [NSMutableDictionary dictionary];
        normalAttributes[NSFontAttributeName] = [UIFont systemFontOfSize:11];
        normalAttributes[NSForegroundColorAttributeName] = [UIColor colorWithRed:128/255.0 green:128/255.0 blue:128/255.0 alpha:1];
        [barItem setTitleTextAttributes:normalAttributes forState:UIControlStateNormal];
        
        NSMutableDictionary *selectedAttributes = [NSMutableDictionary dictionary];
        selectedAttributes[NSFontAttributeName] = [UIFont systemFontOfSize:11];
        selectedAttributes[NSForegroundColorAttributeName] = [UIColor orangeColor];
        [barItem setTitleTextAttributes:selectedAttributes forState:UIControlStateSelected];
    }
    HLCenterBar *tabBar = [HLCenterBar new];
    
    tabBar.delegate = self;
    //使用kvc，将自定义的tabbar替换掉系统的tabbar
    [self setValue:tabBar forKey:@"tabBar"];
    
}

#pragma mark - HLCenterBarDelegate

-(void)tabBarDidClickCenterBar:(HLCenterBar *)bar
{
    [self presentViewController:[MainViewController productViewController] animated:YES completion:nil];
    
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
