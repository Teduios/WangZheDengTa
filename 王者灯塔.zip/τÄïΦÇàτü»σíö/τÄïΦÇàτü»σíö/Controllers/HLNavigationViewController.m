//
//  HLNavigationViewController.m
//  王者灯塔
//
//  Created by tarena on 16/1/4.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "HLNavigationViewController.h"

@interface HLNavigationViewController ()

@end

@implementation HLNavigationViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

/*对NavigationBar进行设计*/
+(void)initialize
{
    //避免重复调用
    if (self==[HLNavigationViewController class]) {
        UINavigationBar*bar=[UINavigationBar appearance];
        [bar setBackgroundColor:[UIColor lightGrayColor]];
        [bar setBackgroundImage:[[UIImage imageNamed:@"backew.png"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] forBarMetrics:UIBarMetricsDefault];
        [bar setBarStyle:UIBarStyleDefault];
        NSMutableDictionary*worldAttibutes=[NSMutableDictionary dictionary];
        worldAttibutes[NSForegroundColorAttributeName]=[UIColor orangeColor];
        worldAttibutes[NSFontAttributeName]=[UIFont italicSystemFontOfSize:19];
        [bar setTitleTextAttributes:worldAttibutes];
        //UIImage *selectedImage = [vc.tabBarItem.selectedImage imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];vc.tabBarItem.selectedImage = selectedImage;
        
        
    }
}










- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
