//
//  HLCenterBar.m
//  王者灯塔
//
//  Created by tarena on 16/1/4.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "HLCenterBar.h"

@interface HLCenterBar()
@property(nonatomic,strong)UIButton*centerButton;

@end

@implementation HLCenterBar

-(instancetype)initWithFrame:(CGRect)frame
{
    if (self=[super initWithFrame:frame]) {
        self.centerButton=[UIButton new];
        [self.centerButton setBackgroundImage:[UIImage imageNamed:@"normal.png"] forState:UIControlStateHighlighted];
        [self.centerButton setBackgroundImage:[UIImage imageNamed:@"highlight.png"] forState:UIControlStateNormal];
        CGRect frame=CGRectZero;
        frame.size=self.centerButton.currentBackgroundImage.size;
        self.centerButton.backgroundColor=[UIColor clearColor];
        self.centerButton.frame=frame;
        
        /*这里为按钮添加事件*/
        [self.centerButton addTarget:self action:@selector(clickCenterButton) forControlEvents:UIControlEventTouchUpInside];
        
        [self addSubview:self.centerButton];
    }
    return self;
}

-(void)clickCenterButton
{
    
    [self.delegate tabBarDidClickCenterBar:self];

}


-(void)layoutSubviews
{
    [super layoutSubviews];
    
    //1.设置中间按钮的位置
    CGPoint center = CGPointMake(self.bounds.size.width*0.5, self.bounds.size.height*0.5-12);
    self.centerButton.center = center;
    
    //2.设置其他tabBarItem的位置和尺寸
    CGFloat tabBarButtonW = self.bounds.size.width / 5;
    
    CGFloat buttonIndex = 0;
    //遍历tabBar中的所有子视图
    //只有当遍历到的子视图的类型是UITabBarButton
    //时，才代表找到的其他按钮，调整位置即可
    for (UIView *child in self.subviews) {
        //获取UITabBarButton的类型描述信息
        Class class = NSClassFromString(@"UITabBarButton");
        if ([child isKindOfClass:class]) {
            CGRect frame = child.frame;
            //设置宽度
            frame.size.width = tabBarButtonW;
            //设置横向x
            frame.origin.x = tabBarButtonW * buttonIndex;
            
            child.frame = frame;
            
            buttonIndex++;
            if (buttonIndex==2) {
                buttonIndex++;
            }
        }
    }

}


@end
