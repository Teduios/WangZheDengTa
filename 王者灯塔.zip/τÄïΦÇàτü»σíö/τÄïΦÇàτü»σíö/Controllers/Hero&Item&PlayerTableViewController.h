//
//  Hero&Item&PlayerTableViewController.h
//  王者灯塔
//
//  Created by tarena on 16/1/25.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Hero_Item_PlayerTableViewController : UITableViewController

@property(nonatomic,assign)NSInteger idx;

@end
