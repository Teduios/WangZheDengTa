//
//  ItemViewController.h
//  王者灯塔
//
//  Created by tarena on 16/1/25.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ItemViewController : UITableViewController

@property(nonatomic,strong)NSString * url;

@end
