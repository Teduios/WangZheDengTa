//
//  HLQQViewController.m
//  王者灯塔
//
//  Created by tarena on 16/1/29.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "HLQQViewController.h"

#define WIDTH [UIScreen mainScreen].bounds.size.width
#define HEIGHT [UIScreen mainScreen].bounds.size.height

@interface HLQQViewController ()
@property (weak, nonatomic) IBOutlet UIWebView *WebView;

@end

@implementation HLQQViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.WebView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:@"http://www.jlszyy.com/topic/lolzhoumian/"]]];
    [self createNavi];
    [self createTab];
    
}

-(void)createNavi
{
    UIView *view=[[UIView alloc]init];
    view.frame=CGRectMake(0, 0, WIDTH, 64);
    view.backgroundColor=[UIColor whiteColor];
    
    UIButton* button=[UIButton new];
    [button setImage:[UIImage imageNamed:@"navigationbar_back_highlighted@2x"] forState:UIControlStateHighlighted];
    [button setImage:[UIImage imageNamed:@"navigationbar_back@2x"] forState:UIControlStateNormal];
    [button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [button setTitleColor:[UIColor orangeColor] forState:UIControlStateHighlighted];
    button.titleLabel.font=[UIFont systemFontOfSize:16];
    button.frame=CGRectMake(15, 25, 30, 39);
    [button addTarget:self action:@selector(goBack) forControlEvents:UIControlEventTouchUpInside];
    
    UIButton* center=[UIButton new];
    [center setImage:[UIImage imageNamed:@"myLoc.png"] forState:0];
    center.userInteractionEnabled=NO;
    center.frame=CGRectMake(WIDTH/2-70, 25, 140, 40);
    
    [view addSubview:center];
    [view addSubview:button];
    [self.view addSubview:view];
}

-(void)createTab
{
    UIView* view =[UIView new];
    view.frame=CGRectMake(0, HEIGHT-50, WIDTH, 150);
    UIImageView* imageView=[[UIImageView alloc]init];
    imageView.frame=CGRectMake(0, 0, WIDTH, 150);
    imageView.image=[UIImage imageNamed:@"tabbar2.png"];
    [view addSubview:imageView];
    [self.view addSubview:view];
}

-(void)goBack
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
