//
//  SearchViewController.h
//  王者灯塔
//
//  Created by tarena on 16/1/27.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SearchViewController : UIViewController

@end
