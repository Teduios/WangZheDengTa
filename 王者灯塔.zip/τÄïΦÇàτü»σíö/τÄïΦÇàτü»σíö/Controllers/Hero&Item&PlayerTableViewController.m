//
//  Hero&Item&PlayerTableViewController.m
//  王者灯塔
//
//  Created by tarena on 16/1/25.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "Hero&Item&PlayerTableViewController.h"
#import "HLHeroAndProductTableViewCell.h"
#import "HLPlayerTableViewCell.h"
#import "HeroInfomation.h"
#import "PlayerInfomation.h"
#import "ItemViewController.h"
#import "HeroItemDetailViewController.h"
#import "MJRefresh.h"
#import "HLNetModle.h"
#import "NSData+alalysisHtml.h"
#import "NSString+getInfomation.h"
#import "UIImageView+WebCache.h"
#import "HLPlayerViewController.h"
#import "HLNavigationViewController.h"
#import "HLAlertView.h"

static NSInteger titleTableTag = 300;
static NSInteger tableTag = 301;

#define WIDTH  [UIScreen mainScreen].bounds.size.width
#define HEIGHT [UIScreen mainScreen].bounds.size.height

#define HERO_URLString @"http://www.lolmax.com/hero/?time=%@&tier=%@&mode=%@"
#define ITEM_URLString @"http://www.lolmax.com/item/?time=%@&tier=%@&mode=%@"
#define PLAYER_URLString @"http://www.lolmax.com/player/?area_id=%@"
#define ARRAY_DATA_TITLETABLE_1 @[@[@"本月", @"s5赛季"], @[@"全部", @"最强王者", @"钻石", @"铂金", @"黄金", @"白银", @"青铜", @"超凡大师"], @[@"全部", @"匹配赛", @"排位赛", @"战队赛", @"统治战场"]]
#define ARRAY_DATA_TITLETABLE_0 @[@[@"艾欧尼亚 (电信一)", @"祖安 (电信二)", @"诺克萨斯 (电信三)", @"班德尔城 (电信四)", @"皮尔特沃夫 (电信五)", @"战争学院 (电信六)", @"巨神峰 (电信七)", @"雷瑟守备 (电信八)", @"裁决之地 (电信九)", @"黑色玫瑰 (电信十)", @"暗影岛 (电信十一)", @"钢铁烈阳 (电信十二)", @"均衡教派 (电信十三)", @"水晶之痕 (电信十四)", @"影流 (电信十五)", @"守望之海 (电信十六)", @"征服之海 (电信十七)", @"卡拉曼达 (电信十八)", @"皮城警备 (电信十九)", @"比尔吉沃特 (网通一)", @"德玛西亚 (网通二)", @"弗雷尔卓德 (网通三)", @"无畏先锋 (网通四)", @"恕瑞玛 (网通五)", @"扭曲丛林 (网通六)", @"巨龙之巢 (网通七)", @"教育网专区 (教育网)"]]


@interface Hero_Item_PlayerTableViewController ()

@end

@implementation Hero_Item_PlayerTableViewController

{
    UITableView *_titleTableView;
    NSMutableArray *_closeArray;
    UIView *_bacView;
    NSArray *_titleDataArray;
    NSMutableArray *_titleBtnText;
    NSMutableArray *_dataArray;
    UITableView *_tableView;
    NSString *_time;
    NSString *_mode;
    NSString *_tier;
    NSString *_area_id;
    float _maxScore;
    NSMutableArray *resultArray;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self createTitle];
    self.tableView.scrollEnabled=NO;
    [self createNavi];
    [self createTab];

    
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
   
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self createItemTitle];
}

-(void)createTab
{
    UIView* view =[UIView new];
    view.frame=CGRectMake(0, HEIGHT-50, WIDTH, 150);
    UIImageView* imageView=[[UIImageView alloc]init];
    imageView.frame=CGRectMake(0, 0, WIDTH, 150);
    imageView.image=[UIImage imageNamed:@"tabbar2.png"];
    [view addSubview:imageView];
    [self.view addSubview:view];
}

-(void)createNavi
{
    UIView *view=[[UIView alloc]init];
    view.frame=CGRectMake(0, 20, WIDTH, 44);
    view.backgroundColor=[UIColor whiteColor];
   
    UIButton* button=[UIButton new];
    [button setImage:[UIImage imageNamed:@"navigationbar_back_highlighted@2x"] forState:UIControlStateHighlighted];
    [button setImage:[UIImage imageNamed:@"navigationbar_back@2x"] forState:UIControlStateNormal];
    [button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [button setTitleColor:[UIColor orangeColor] forState:UIControlStateHighlighted];
    button.titleLabel.font=[UIFont systemFontOfSize:16];
    button.frame=CGRectMake(15, 5, 30, 39);
    [button addTarget:self action:@selector(goBack) forControlEvents:UIControlEventTouchUpInside];
    
    UIButton* center=[UIButton new];
    [center setImage:[UIImage imageNamed:@"myLoc.png"] forState:0];
    center.userInteractionEnabled=NO;
    center.frame=CGRectMake(WIDTH/2-70, 5, 140, 40);
    
    [view addSubview:center];
    [view addSubview:button];
    [self.view addSubview:view];
}

-(void)goBack
{
    [self dismissViewControllerAnimated:YES completion:nil];
}


-(void)createTitle
{
    _closeArray = [@[@"0", @"0", @"0"] mutableCopy];
    _titleTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 64, WIDTH, 90) style:UITableViewStylePlain];
    _titleTableView.bounces = NO;
    _titleTableView.delegate = self;
    _titleTableView.dataSource = self;
    _titleTableView.tag = titleTableTag;
    [self.view addSubview:_titleTableView];
}

- (void)creatContent
{
    [_bacView removeFromSuperview];
    
    _bacView = [[UIView alloc] initWithFrame:CGRectMake(0, 30 * [_titleDataArray count] + 64, WIDTH, HEIGHT - 30 * [_titleDataArray count] - 64 - 49)];
    _bacView.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:_bacView];
    
    NSArray *array = nil;
    
    if (_idx == 0)
    {
        array = @[@"英雄", @"胜率", @"场次"];
    }
    else if (_idx == 1)
    {
        array = @[@"物品", @"胜率", @"场次"];
    }
    else
    {
        array = @[@"玩家", @"段位", @"胜点", @"隐藏分"];
    }
    
    for (int i = 0; i < [array count]; i++)
    {
        UIView *view = [[UIView alloc] initWithFrame:CGRectMake(i * WIDTH / [array count], 0, WIDTH / [array count], 1)];
        view.backgroundColor = [UIColor blackColor];
        [_bacView addSubview:view];
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(i * WIDTH / [array count], 1, WIDTH / [array count], 38)];
        label.text = array[i];
        label.backgroundColor = [UIColor whiteColor];
        label.textAlignment = NSTextAlignmentCenter;
        label.font = [UIFont boldSystemFontOfSize:20];
        label.textColor = [UIColor blackColor];
        [_bacView addSubview:label];
        
        UIView *view1 = [[UIView alloc] initWithFrame:CGRectMake(i * WIDTH / [array count], 39, WIDTH / [array count], 1)];
        view1.backgroundColor = [UIColor blackColor];
        [_bacView addSubview:view1];
        
    }
    
    _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 40, WIDTH, HEIGHT - 64 - 90 - 40 - 49) style:UITableViewStylePlain];
    
    if (_idx == 2)
    {
        _tableView.frame = CGRectMake(0, 40, WIDTH, HEIGHT - 64 - 30 - 40 - 49);
    }
    
    _tableView.tag = tableTag;
    _tableView.delegate = self;
    _tableView.dataSource = self;
    _tableView.backgroundColor = [UIColor whiteColor];
    _tableView.header = [MJRefreshNormalHeader headerWithRefreshingTarget:self refreshingAction:@selector(headRefresh)];
    _dataArray = [[NSMutableArray alloc] init];
    [_tableView.header beginRefreshing];
    [_bacView addSubview:_tableView];
}

-(void)headRefresh
{
    NSString *url = nil;
    
    if (_idx == 0)
    {
        url = [NSString stringWithFormat:HERO_URLString, _time, _tier, _mode];
    }
    else if (_idx == 1)
    {
        url = [NSString stringWithFormat:ITEM_URLString, _time, _tier, _mode];
    }
    else
    {
        url = [NSString stringWithFormat:PLAYER_URLString, _area_id];
    }
    
    [self getData:url];

}

-(void)getData:(NSString*)url
{
    [HLNetModle htmlGetHttpURL:url success:^(id Object) {
        [_dataArray removeAllObjects];
        
        if (_idx == 2 )
        {
            NSArray *array = [NSData analysisHtml:Object ByString:@"<option value=.*?<"];
            resultArray = [[NSMutableArray alloc] init];
            
            for (NSString *subString in array)
            {
                NSMutableArray *mArray = [[NSMutableArray alloc] init];
                NSMutableString *value = [[subString getInfomation:@"\".*?\""] mutableCopy];
                NSMutableString *name = [[subString getInfomation:@">.*?<"] mutableCopy];
                NSRange range;
                
                while ((range = [value rangeOfString:@"\""]).location != NSNotFound)
                {
                    [value deleteCharactersInRange:range];
                }
                [name deleteCharactersInRange:[name rangeOfString:@"<"]];
                [name deleteCharactersInRange:[name rangeOfString:@">"]];
                
                [mArray addObject:name];
                [mArray addObject:value];
                [resultArray addObject:mArray];
            }
            
            //[_dataArray addObject:[resultArray copy]];
            
            array = [NSData analysisHtml:Object ByString:@"<tr onclick.*?</tr>"];
            
            for (NSString *subString in array)
            {
                NSMutableString *icon;
                NSMutableString *name;
                NSMutableString *grade;
                NSMutableString *win;
                NSMutableString *score;
                NSMutableString *donav;
                
                icon = [[[subString getInfomation:@"src=\".*?\""] getInfomation:@"\".*?\""] mutableCopy];
                
                NSRange range;
                
                while ((range = [icon rangeOfString:@"\""]).location != NSNotFound)
                {
                    [icon deleteCharactersInRange:range];
                }
                
                name = [[[subString getInfomation:@"4px;\">.*?<"] getInfomation:@">.*?<"] mutableCopy];
                [name deleteCharactersInRange:[name rangeOfString:@">"]];
                [name deleteCharactersInRange:[name rangeOfString:@"<"]];
                
                while ((range = [name rangeOfString:@" "]).location != NSNotFound || (range = [name rangeOfString:@"\n"]).location != NSNotFound)
                {
                    [name deleteCharactersInRange:range];
                }
                
                grade = [[[[subString getInfomation:@"</td><td>.*?</td>"] getInfomation:@"<td>.*?</"] getInfomation:@">.*?<"] mutableCopy];
                [grade deleteCharactersInRange:[grade rangeOfString:@">"]];
                [grade deleteCharactersInRange:[grade rangeOfString:@"<"]];
                
                while ((range = [grade rangeOfString:@" "]).location != NSNotFound || (range = [grade rangeOfString:@"\n"]).location != NSNotFound)
                {
                    [grade deleteCharactersInRange:range];
                }
                
                NSArray *subArray = [subString getInfomations:@"10px\">.*?</div>"];
                win = [[subArray[0] getInfomation:@">.*?<"] mutableCopy];
                [win deleteCharactersInRange:[win rangeOfString:@">"]];
                [win deleteCharactersInRange:[win rangeOfString:@"<"]];
                
                while ((range = [win rangeOfString:@" "]).location != NSNotFound || (range = [win rangeOfString:@"\n"]).location != NSNotFound)
                {
                    [win deleteCharactersInRange:range];
                }
                score = [[subArray[1] getInfomation:@">.*?<"] mutableCopy];
                [score deleteCharactersInRange:[score rangeOfString:@">"]];
                [score deleteCharactersInRange:[score rangeOfString:@"<"]];
                
                donav = [[[subString getInfomation:@"DoNav.*?\""] getInfomation:@"'.*?'"] mutableCopy];
                donav = [[donav deleteString:@[@"'"]] mutableCopy];
                
                while ((range = [score rangeOfString:@" "]).location != NSNotFound || (range = [score rangeOfString:@"\n"]).location != NSNotFound)
                {
                    [score deleteCharactersInRange:range];
                }
                
                if ([score floatValue] > _maxScore)
                {
                    _maxScore = [score floatValue];
                }
                
                PlayerInfomation *player = [[PlayerInfomation alloc] init];
                player.icon = icon;
                player.name = name;
                player.grade = grade;
                player.win = win;
                player.score = score;
                player.donav = donav;
                [_dataArray addObject:player];
                
            }
            
        }
        else
        {
            NSArray *array = [NSData analysisHtml:Object ByString:@"DoNav.*?</tr>"];
            NSMutableString *icon;
            NSMutableString *name;
            NSMutableString *win;
            NSMutableString *times;
            NSMutableString *donav;
            
            for (NSString *subString in array)
            {
                icon = [[[subString getInfomation:@"src=\".*?\""] getInfomation:@"\".*?\""] mutableCopy];
                NSRange range;
                
                while ((range = [icon rangeOfString:@"\""]).location != NSNotFound)
                {
                    [icon deleteCharactersInRange:range];
                }
                
                name = [[[subString getInfomation:@"style=\"margin:3px;\" />(.*?)<"] getInfomation:@">.*?<"] mutableCopy];
                [name deleteCharactersInRange:[name rangeOfString:@">"]];
                [name deleteCharactersInRange:[name rangeOfString:@"<"]];
                
                while ((range = [name rangeOfString:@" "]).location != NSNotFound || (range = [name rangeOfString:@"\n"]).location != NSNotFound)
                {
                    [name deleteCharactersInRange:range];
                }
                
                NSArray *subArray = [subString getInfomations:@"style=\"height: 10px\".*?<"];
                win = [[subArray[0] getInfomation:@">.*?<"] mutableCopy];
                [win deleteCharactersInRange:[win rangeOfString:@">"]];
                [win deleteCharactersInRange:[win rangeOfString:@"<"]];
                times = [[subArray[1] getInfomation:@">.*?<"] mutableCopy];
                [times deleteCharactersInRange:[times rangeOfString:@">"]];
                [times deleteCharactersInRange:[times rangeOfString:@"<"]];
                donav = [[[subString getInfomation:@"DoNav.*?\""] getInfomation:@"'.*?'"] mutableCopy];
                donav = [[donav deleteString:@[@"'"]] mutableCopy];
                
                HeroInfomation *hero = [[HeroInfomation alloc] init];
                hero.name = name;
                hero.icon = icon;
                hero.win = win;
                hero.times = times;
                hero.donav = donav;
                
                [_dataArray addObject:hero];
            }
            
            for (NSUInteger i = 0; i < [_dataArray count]; i++)
            {
                for (NSUInteger j = 0; j < [_dataArray count] - i - 1; j++)
                {
                    
                    if ([((HeroInfomation *)_dataArray[j]).win floatValue] < [((HeroInfomation *)_dataArray[j + 1]).win floatValue])
                    {
                        HeroInfomation *hero = [(HeroInfomation *)_dataArray[j]  copy];
                        [_dataArray replaceObjectAtIndex:j withObject:_dataArray[j+1]];
                        [_dataArray replaceObjectAtIndex:(j+1) withObject:hero];
                    }
                }
            }
        }
        
        [_tableView reloadData];
        [_tableView.header endRefreshing];

    } failure:^(NSError *error) {
        HLAlertView *alertView = [[HLAlertView alloc] initWithtitle:@"网络不好,请稍后重试" target:self.view];
        [alertView show];
        [_tableView.header endRefreshing];
    } progress:^(NSProgress *progress) {
        
    }];
}

- (void)headBtnClick:(UIButton *)btn
{
    NSInteger section = btn.tag - 1000;
    
    if ([_closeArray[section] isEqualToString:@"0"])
    {
        [btn setImage:[UIImage imageNamed:@"left.png"] forState:UIControlStateNormal];
        
        for (int i = 0; i < [_closeArray count]; i++)
        {
            if (i == section)
            {
                [_closeArray replaceObjectAtIndex:section withObject:@"1"];
            }
            else
            {
                [_closeArray replaceObjectAtIndex:i withObject:@"0"];
            }
        }
        
        
        CGFloat height = [_titleDataArray[section] count] * 30 + 30 * [_titleDataArray count] + 64;
        
        if (height > HEIGHT)
        {
            height = HEIGHT - 49;
        }
        
        _bacView.frame = CGRectMake(0, height, WIDTH, HEIGHT - height - 49);
        _titleTableView.frame = CGRectMake(0, 64, WIDTH, height - 64);
        
    }
    else
    {
        [btn setImage:[UIImage imageNamed:@"down.png"] forState:UIControlStateNormal];
        [_closeArray replaceObjectAtIndex:section withObject:@"0"];
        _titleTableView.frame = CGRectMake(0, 64, WIDTH, 30 * [_titleDataArray count]);
        _bacView.frame = CGRectMake(0, 30 * [_titleDataArray count] + 64, WIDTH, HEIGHT - 30 * [_titleDataArray count] - 64 - 49);
        
    }
    [_titleTableView reloadData];
}

-(void)createItemTitle
{
    if (self.idx == 2)
    {
        _titleDataArray = ARRAY_DATA_TITLETABLE_0;
        _area_id = @"1";
        
    }
    
    else
    {
        _titleDataArray = ARRAY_DATA_TITLETABLE_1;
        
        _time = @"month";
        _tier = @"all";
        _mode = @"all";
    }
    
    _titleBtnText = [[NSMutableArray alloc] init];
    
    for (NSArray *array in _titleDataArray)
    {
        [_titleBtnText addObject:array[0]];
    }
    
    _titleTableView.frame = CGRectMake(0, 64, WIDTH, 30 * [_titleDataArray count]);
    _bacView.frame = CGRectMake(0, 64 + 30 * [_titleDataArray count], WIDTH, HEIGHT - 64 - 30 * [_titleDataArray count] - 49);
    [self creatContent];
    [_titleTableView reloadData];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    if (tableView.tag == titleTableTag)
    {
        return [_titleDataArray count];
    }
    
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    if (tableView.tag == titleTableTag)
    {
        if ([_closeArray[section] isEqualToString:@"0"])
        {
            return 0;
        }
        
        return [_titleDataArray[section] count];
    }
    
    if (_idx == 2)
    {
        return [_dataArray  count];
    }
    return [_dataArray count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (tableView.tag == titleTableTag)
    {
        static NSString *iden = @"iden";
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:iden];
        
        if (cell == nil)
        {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:iden];
        }
        
        cell.textLabel.text = _titleDataArray[indexPath.section][indexPath.row];
        cell.textLabel.textColor = [UIColor orangeColor];
        cell.textLabel.font = [UIFont systemFontOfSize:15];
        cell.backgroundColor = [UIColor whiteColor];
        
        return cell;
        
    }
    
    else
    {
        if (_idx == 0 || _idx == 1)
        {
           HLHeroAndProductTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"HeroAndItemCell"];
            
            if (!cell)
            {
                cell = [[[NSBundle mainBundle] loadNibNamed:@"HLHeroAndProductTableViewCell" owner:nil options:nil] lastObject];
            }
            HeroInfomation *hero = (HeroInfomation *)_dataArray[indexPath.row];
            cell.nameLable.text = hero.name;
            cell.winProgress.progress = [hero.win floatValue] / 100.0;
            [cell.iconView sd_setImageWithURL:[NSURL URLWithString:hero.icon]];
            cell.winLable.text = hero.win;
            cell.timesLable.text = hero.times;
            return cell;
        }
        else
        {
            HLPlayerTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"PlayerCell"];
            if (!cell)
            {
                cell = [[[NSBundle mainBundle] loadNibNamed:@"HLPlayerTableViewCell" owner:nil options:nil] lastObject];
            }
            PlayerInfomation *player = (PlayerInfomation *)_dataArray[indexPath.row];
            cell.nameLable.text = player.name;
            static CGFloat maxWin;
            if (indexPath.row == 0)
            {
                maxWin = [player.win floatValue];
            }
            
            cell.winProgress.progress = [player.win floatValue] / maxWin;
            cell.scoreProgress.progress = [player.score floatValue] / _maxScore;
            [cell.iconView sd_setImageWithURL:[NSURL URLWithString:player.icon]];
            cell.winLable.text = player.win;
            cell.scoreLable.text = player.score;
            cell.gradeLable.text = player.grade;
            return cell;
        }
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if (tableView.tag == titleTableTag)
    {
        return 30;
    }
    
    return 0;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 0;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (tableView.tag == titleTableTag)
    {
        return 40;
    }
    return 60;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    if (tableView.tag == titleTableTag)
    {
        NSArray *titleArray = nil;
        
        if (_idx == 0 || _idx == 1)
        {
            titleArray = @[@"时间:", @"段位:", @"比赛模式:", @""];
        }
        else
        {
            titleArray = @[@"服务器:", @""];
        }
        
        UIButton *headerView = [UIButton buttonWithType:UIButtonTypeCustom];
        headerView.backgroundColor = [UIColor whiteColor];
        if ([_closeArray[section] isEqualToString:@"0"])
        {
            [headerView setImage:[UIImage imageNamed:@"left.png"] forState:UIControlStateNormal];
        }
        else
        {
            [headerView setImage:[UIImage imageNamed:@"down.png"] forState:UIControlStateNormal];
        }
        [headerView setImageEdgeInsets:UIEdgeInsetsMake(0, 10, 0, WIDTH-30)];
        [headerView setTitle:_titleBtnText[section] forState:UIControlStateNormal];
        [headerView setTitleColor:[UIColor orangeColor] forState:UIControlStateNormal];
        headerView.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
        headerView.tag = 1000 + section;
        [headerView addTarget:self action:@selector(headBtnClick:) forControlEvents:UIControlEventTouchUpInside];
        UILabel *titleLable = [[UILabel alloc] initWithFrame:CGRectMake(40, 0, 100, 30)];
        titleLable.text = titleArray[section];
        titleLable.textColor = [UIColor blackColor];
        titleLable.textAlignment = NSTextAlignmentLeft;
        [headerView addSubview:titleLable];
        return headerView;
    }
    
    return nil;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (tableView.tag == titleTableTag)
    {
        [_titleBtnText replaceObjectAtIndex:indexPath.section withObject:_titleDataArray[indexPath.section][indexPath.row]];
        [self headBtnClick:(UIButton *)[self.view viewWithTag:1000 + indexPath.section]];
        
        if (_idx == 2)
        {
            for (int i = 0; i < [resultArray count]; i++)
            {
                
                
                if ([ARRAY_DATA_TITLETABLE_0[0][indexPath.row] isEqualToString:resultArray[i][0]])
                {
                    _area_id = resultArray[i][1];
                    break;
                }
            }
            
        }
        else
        {
            if (indexPath.section == 2)
            {
                if (indexPath.row == 4)
                {
                    _mode = @"8";
                }
                else if (indexPath.row == 0)
                {
                    _mode = @"all";
                }
                else
                {
                    _mode = [NSString stringWithFormat:@"%lu", indexPath.row + 2];
                }
            }
            else if (indexPath.section == 1)
            {
                if (indexPath.row == 0)
                {
                    _tier = @"all";
                }
                else
                {
                    _tier = [NSString stringWithFormat:@"%lu", indexPath.row - 1];
                }
            }
            else
            {
                if (indexPath.row == 0)
                {
                    _time = @"month";
                }
                else
                {
                    _time = @"all";
                }
            }
        }
        [_tableView.header beginRefreshing];
        
    }
    else
    {
        NSString *url = ((HeroInfomation *)_dataArray[indexPath.row]).donav;
        
        if (_idx == 1)
        {
            ItemViewController *item = [[ItemViewController alloc] init];
            item.url = [NSString stringWithFormat:@"http://www.lolmax.com%@", url];
            [self presentViewController:item animated:YES completion:nil];
        }
        else if (_idx == 0)
        {
            HeroItemDetailViewController *detail = [[HeroItemDetailViewController alloc] init];
            detail.url = [NSString stringWithFormat:@"http://www.lolmax.com%@", url];
            
            [self presentViewController:detail animated:YES completion:nil];
            
        }
        else
        {
            HLPlayerViewController *player = [[HLPlayerViewController alloc] init];
            player.url = [NSString stringWithFormat:@"http://www.lolmax.com%@", [_dataArray[indexPath.row] donav]];
            [self presentViewController:player animated:YES completion:nil];
        }
    }
}





/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
