//
//  MainViewController.m
//  王者灯塔
//
//  Created by tarena on 16/1/6.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "MainViewController.h"
#import "Masonry.h"
#import "Hero&Item&PlayerTableViewController.h"
#import "HLQQViewController.h"

@interface MainViewController ()

@property(nonatomic,strong)Hero_Item_PlayerTableViewController*vc;

@end

@implementation MainViewController

+(UIViewController *)productViewController
{
    return [[self alloc]initWithView];
}

-(Hero_Item_PlayerTableViewController *)vc
{
    if (!_vc) {
        _vc=[[Hero_Item_PlayerTableViewController alloc]init];
    }
    return _vc;
}

-(UIViewController*)initWithView
{
    if (self=[super init]) {
        self.view.backgroundColor=[UIColor whiteColor];
        UIImageView*imageView=[[UIImageView alloc]initWithFrame:[UIScreen mainScreen].bounds];
        [self.view addSubview:imageView];
        
        /*这里添加主背景图*/
        imageView.image=[UIImage imageNamed:@"4.png"];
        
        UIButton*centerButton=[UIButton new];
        [centerButton setImage:[UIImage imageNamed:@"ruiwen.png"] forState:UIControlStateNormal];
        [centerButton addTarget:self action:@selector(clickCenterButton) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview:centerButton];
        [centerButton mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(self.view.mas_left).mas_equalTo(10);
            make.top.mas_equalTo(self.view.mas_top).mas_equalTo(24);
        }];
        
        UIButton*buttonA=[UIButton new];
        [buttonA setImage:[UIImage imageNamed:@"highlight.png"] forState:UIControlStateNormal];
        [buttonA setImage:[UIImage imageNamed:@"firstButton.png"] forState:UIControlStateHighlighted];
        [buttonA setTitle:@"玩家" forState:UIControlStateNormal];
        [buttonA setTitleColor:[UIColor redColor] forState:UIControlStateHighlighted];
        [buttonA addTarget:self action:@selector(clickButtonA) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview:buttonA];
        [buttonA mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.mas_equalTo(self.view.mas_centerX).mas_equalTo(-80);
            make.centerY.mas_equalTo(self.view.mas_centerY).mas_equalTo(-100);
        }];
        
        UIButton*buttonB=[UIButton new];
        [buttonB setImage:[UIImage imageNamed:@"highlight.png"] forState:UIControlStateNormal];
        [buttonB setImage:[UIImage imageNamed:@"secondButton"] forState:UIControlStateHighlighted];
        [buttonB setTitle:@"英雄" forState:UIControlStateNormal];
        [buttonB setTitleColor:[UIColor blueColor] forState:UIControlStateHighlighted];
        [buttonB addTarget:self action:@selector(clickButtonB) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview:buttonB];
        [buttonB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.mas_equalTo(self.view.mas_centerX).mas_equalTo(100);
            make.centerY.mas_equalTo(self.view.mas_centerY).mas_equalTo(-100);
        }];
        
        UIButton*buttonC=[UIButton new];
        [buttonC setImage:[UIImage imageNamed:@"highlight.png"] forState:UIControlStateNormal];
        [buttonC setImage:[UIImage imageNamed:@"thirdButton"] forState:UIControlStateHighlighted];
        [buttonC setTitle:@"物品" forState:UIControlStateNormal];
        [buttonC setTitleColor:[UIColor purpleColor] forState:UIControlStateHighlighted];
        [buttonC addTarget:self action:@selector(clickButtonC) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview:buttonC];
        [buttonC mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.mas_equalTo(self.view.mas_centerX).mas_equalTo(-80);
            make.centerY.mas_equalTo(self.view.mas_centerY).mas_equalTo(100);
        }];
        
        UIButton*buttonD=[UIButton new];
        [buttonD setImage:[UIImage imageNamed:@"highlight.png"] forState:UIControlStateNormal];
        [buttonD setImage:[UIImage imageNamed:@"forthButton"] forState:UIControlStateHighlighted];
        [buttonD setTitle:@"更多" forState:UIControlStateNormal];
        [buttonD setTitleColor:[UIColor greenColor] forState:UIControlStateHighlighted];
        [buttonD addTarget:self action:@selector(clickButtonD) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview:buttonD];
        [buttonD mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.mas_equalTo(self.view.mas_centerX).mas_equalTo(100);
            make.centerY.mas_equalTo(self.view.mas_centerY).mas_equalTo(100);
        }];
        
    }
    return self;
}

#pragma mark - ButtonTargets

-(void)clickCenterButton
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

-(void)clickButtonA    //玩家
{
    self.vc.idx=2;
    [self presentViewController:self.vc animated:YES completion:nil];
}

-(void)clickButtonB    //英雄
{
    self.vc.idx=0;
    [self presentViewController:self.vc animated:YES completion:nil];
}

-(void)clickButtonC      //物品
{
    self.vc.idx=1;
    [self presentViewController:self.vc animated:YES completion:nil];
}

-(void)clickButtonD      //周免
{
    HLQQViewController* qqVC=[[HLQQViewController alloc]initWithNibName:@"HLQQViewController" bundle:nil];
    [self presentViewController:qqVC animated:YES completion:nil];
}

- (void)viewDidLoad {
    [super viewDidLoad];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
