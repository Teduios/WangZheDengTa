//
//  HLNewsCategoryTableTableViewController.h
//  王者灯塔
//
//  Created by tarena on 16/1/10.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
@class HLNewsCategoryTableTableViewController;
@protocol HLNewsControllerDelegate <NSObject>
-(void)inputViewController:(HLNewsCategoryTableTableViewController*)vc inputFlag:(NSInteger)flag;

@end

@interface HLNewsCategoryTableTableViewController : UITableViewController
@property(nonatomic,weak)id<HLNewsControllerDelegate>delegate;

@end
