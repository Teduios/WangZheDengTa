//
//  HLDetailViewController.m
//  王者灯塔
//
//  Created by tarena on 16/1/15.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "HLDetailViewController.h"
#import "NSString+ParseURLString.h"

@interface HLDetailViewController ()
@property (weak, nonatomic) IBOutlet UIWebView *webView;
- (IBAction)goBackButton:(id)sender;
@property (weak, nonatomic) IBOutlet UIButton *button;

@end

@implementation HLDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:[self.URL parseURLString]]]];
    self.tabBarController.tabBar.hidden=YES;
    [self.button setImage:[UIImage imageNamed:@"navigationbar_back@2x.png"] forState:UIControlStateNormal];
    [self.button setImage:[UIImage imageNamed:@"navigationbar_back_highlighted@2x.png"] forState:UIControlStateHighlighted];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


/*加返回按钮*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)goBackButton:(id)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}
@end
