//
//  HLPlayerViewController.h
//  王者灯塔
//
//  Created by tarena on 16/1/27.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HLPlayerViewController : UITableViewController

@property (nonatomic, strong) NSString *url;
@property (nonatomic, strong) NSString *type;

@end
