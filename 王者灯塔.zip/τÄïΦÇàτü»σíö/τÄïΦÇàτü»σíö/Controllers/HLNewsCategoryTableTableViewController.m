//
//  HLNewsCategoryTableTableViewController.m
//  王者灯塔
//
//  Created by tarena on 16/1/10.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "HLNewsCategoryTableTableViewController.h"
#import "NewsTableViewController.h"

@interface HLNewsCategoryTableTableViewController ()
@property(nonatomic,strong)NSArray*tittles;
@property(nonatomic,strong)NewsTableViewController* newsTableViewController;
@end

@implementation HLNewsCategoryTableTableViewController

-(NSArray *)tittles
{
    if (!_tittles) {
        _tittles=@[@"热点信息",@"新闻动态",@"比赛信息",@"搞笑集锦",@"美女福利",@"取消"];
    }
    return _tittles;
}

-(NewsTableViewController *)newsTableViewController
{
    if (!_newsTableViewController) {
        _newsTableViewController=[[NewsTableViewController alloc]initWithNibName:@"NewsTableViewController" bundle:nil];
    }
    return _newsTableViewController;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    

    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {

    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    return self.tittles.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    /*背景图片*/
    tableView.backgroundView=[[UIImageView alloc]initWithImage:[UIImage imageNamed:@"nvqiang.png"]];
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (!cell) {
        cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    }
        cell.textLabel.text=self.tittles[indexPath.row];
        cell.backgroundColor=[UIColor clearColor];
        cell.accessoryView=[[UIImageView alloc]initWithImage:[UIImage imageNamed:@"left.png"]];
    cell.textLabel.textColor=[UIColor orangeColor];
    
    return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 80;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    switch (indexPath.row) {
        case 0:
            [self.delegate inputViewController:self inputFlag:0];
            [self dismissViewControllerAnimated:YES completion:nil];
            break;
        case 1:
            [self.delegate inputViewController:self inputFlag:1];
            [self dismissViewControllerAnimated:YES completion:nil];
            break;
        case 2:
            [self.delegate inputViewController:self inputFlag:2];
            [self dismissViewControllerAnimated:YES completion:nil];
            break;
        case 3:
            [self.delegate inputViewController:self inputFlag:3];
            [self dismissViewControllerAnimated:YES completion:nil];
            break;
        case 4:
            [self.delegate inputViewController:self inputFlag:4];
            [self dismissViewControllerAnimated:YES completion:nil];
            break;
        case 5:
            [self dismissViewControllerAnimated:YES completion:nil];
            break;
            
        default:
            break;
    }
    
}



/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
