//
//  ItemViewController.m
//  王者灯塔
//
//  Created by tarena on 16/1/25.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "ItemViewController.h"
#import "DrawLine.h"
#import "HeroInfomation.h"
#import "HLHeroAndProductTableViewCell.h"
#import "MJRefresh.h"
#import "HLNetModle.h"
#import "AFNetworking.h"
#import "UIImageView+WebCache.h"
#import "NSData+alalysisHtml.h"
#import "NSString+getInfomation.h"
#import "HLAlertView.h"


#define WIDTH [UIScreen mainScreen].bounds.size.width
#define HEIGHT [UIScreen mainScreen].bounds.size.height
@interface ItemViewController ()
@property(nonatomic,strong)NSMutableArray* titleDataArray;
@property(nonatomic,strong)UIButton* leftButton;

@end

@implementation ItemViewController

{
    DrawLine *_line;
    UIImageView *_titleIcon;
    UILabel *_titleNameLabel;
    UILabel *_titleSecondLabel;
    UILabel *_titleOtherLabel;
    UITableView *_tableView;
    NSMutableArray *_dataArray;
}

-(NSMutableArray *)titleDataArray
{
    if (!_titleDataArray) {
        _titleDataArray=[NSMutableArray array];
    }
    return _titleDataArray;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.leftButton=[UIButton new];
    [self createNavi];
    [self createHeader];
    [self createTableView];
    [self createTab];
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}

-(void)createTab
{
    UIView* view =[UIView new];
    view.frame=CGRectMake(0, HEIGHT-50, WIDTH, 150);
    UIImageView* imageView=[[UIImageView alloc]init];
    imageView.frame=CGRectMake(0, 0, WIDTH, 150);
    imageView.image=[UIImage imageNamed:@"tabbar2.png"];
    [view addSubview:imageView];
    [self.view addSubview:view];
}

-(void)createNavi
{
    UIView *view=[[UIView alloc]init];
    view.frame=CGRectMake(0, 20, WIDTH, 44);
    view.backgroundColor=[UIColor whiteColor];
    
    UIButton* button=[UIButton new];
    [button setImage:[UIImage imageNamed:@"navigationbar_back_highlighted@2x"] forState:UIControlStateHighlighted];
    [button setImage:[UIImage imageNamed:@"navigationbar_back@2x"] forState:UIControlStateNormal];
    [button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [button setTitleColor:[UIColor orangeColor] forState:UIControlStateHighlighted];
    button.titleLabel.font=[UIFont systemFontOfSize:16];
    button.frame=CGRectMake(15, 5, 30, 39);
    [button addTarget:self action:@selector(goBack) forControlEvents:UIControlEventTouchUpInside];
    
    UIButton* center=[UIButton new];
    [center setImage:[UIImage imageNamed:@"myLoc.png"] forState:0];
    center.userInteractionEnabled=NO;
    center.frame=CGRectMake(WIDTH/2-70, 5, 140, 40);
    
    [view addSubview:center];
    [view addSubview:button];
    [self.view addSubview:view];
}

-(void)goBack
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

-(void)createHeader
{
    UIView *titleView = [[UIView alloc] initWithFrame:CGRectMake(0, 64, WIDTH, 100)];
    titleView.backgroundColor = [UIColor lightGrayColor];
    [self.view addSubview:titleView];
    _titleIcon = [[UIImageView alloc] initWithFrame:CGRectMake(WIDTH / 3 - 80, 5, 80, 80)];
    _titleIcon.layer.cornerRadius = 40;
    _titleIcon.layer.masksToBounds = YES;
    _titleIcon.backgroundColor = [UIColor clearColor];
    
    _titleNameLabel = [[UILabel alloc] init];
    _titleSecondLabel = [[UILabel alloc] init];
    _titleOtherLabel = [[UILabel alloc] init];
    
    NSArray *array = @[_titleNameLabel, _titleSecondLabel, _titleOtherLabel];
    
    for (int i = 0; i < [array count]; i++)
    {
        UILabel *label = array[i];
        label.frame = CGRectMake(WIDTH / 3 + 10,5 + 30 * i, WIDTH - (WIDTH / 3 + 10), 30);
        
        if (i == 0)
        {
            label.textColor = [UIColor blackColor];
            label.font = [UIFont boldSystemFontOfSize:20];
        }
        else
        {
            label.textColor = [UIColor blackColor];
            label.font = [UIFont systemFontOfSize:13];
        }
        
        [titleView addSubview:label];
    }
    
    [titleView addSubview:_titleIcon];
    
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, _titleOtherLabel.frame.origin.y + 35, WIDTH, 1)];
    view.backgroundColor = [UIColor lightGrayColor];
    view.alpha = 0.7;
    [titleView addSubview:view];
    
    NSArray *titleArray = @[@"英雄",  @"使用次数", @"胜率"];
    
    for (int i = 0; i < 3; i++)
    {
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(i * WIDTH / 3, 101 + 64, WIDTH / 3, 30)];
        label.text = titleArray[i];
        label.textColor = [UIColor blackColor];
        label.textAlignment = NSTextAlignmentCenter;
        label.font = [UIFont boldSystemFontOfSize:15];
        [self.view addSubview:label];
        
        UIView *lineview = [[UIView alloc] initWithFrame:CGRectMake(17 + i * WIDTH, 131 + 64, WIDTH - 17, 1)];
        lineview.backgroundColor = [UIColor lightGrayColor];
        lineview.alpha = 0.2;
        [self.view addSubview:lineview];
    }
}

-(void)createTableView
{
    _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 132 + 64, WIDTH, HEIGHT - 132 - 64 -49)];

    _tableView.delegate = self;
    _tableView.dataSource = self;
    _tableView.header = [MJRefreshNormalHeader headerWithRefreshingTarget:self refreshingAction:@selector(headRefresh)];
    [_tableView.header beginRefreshing];
    [self.view addSubview:_tableView];
    [self.view sendSubviewToBack:_tableView];
}

-(void)headRefresh
{
    _titleDataArray = [[NSMutableArray alloc] init];
    _dataArray = [[NSMutableArray alloc] init];
    [self getData:self.url];
}

-(void)getData:(NSString*)url
{
    [HLNetModle htmlGetHttpURL:url success:^(id Object) {
        NSString *titleIcon = [[NSData analysisHtml:Object ByString:@"<img src=\".*?\""][1] getInfomation:@"\".*?\""];
        [_titleDataArray addObject:[titleIcon deleteString:@[@"\""]]];
        NSString *titleName = [[NSData analysisHtml:Object ByString:@"style=\"padding-top: 3px;\">.*?<"][0] getInfomation:@">.*?<"];
        [_titleDataArray addObject:[titleName deleteString:@[@"<", @">", @" ", @"\n"]]];
        NSString *other = [[NSData analysisHtml:Object ByString:@"<span style=\"font-size:10px;.*?</"][0] getInfomation:@">.*?<"];
        [_titleDataArray addObject:[[[other deleteString:@[@"<", @">", @" "]] componentsSeparatedByString:@"\n"] componentsJoinedByString:@" "]];
        NSString *times = [NSData analysisHtml:Object ByString:@"使用次数:.*?<"][0];
        NSString *win = [NSData analysisHtml:Object ByString:@"胜率:.*?<"][0];
        [_titleDataArray addObject:[NSString stringWithFormat:@"%@,%@", [times deleteString:@[@" ", @"<"]], [win deleteString:@[@" ", @"<"]]]];
        
        [self refreshTitle];
        
        
        NSArray *items = nil;
        items = [NSData analysisHtml:Object ByString:@"DoNav.*?</tr>"];
        
        for (NSString *subString  in items)
        {
            
            NSMutableString *micon;
            NSMutableString *mname;
            NSMutableString *mtimes;
            NSMutableString *mwin;
            NSMutableString *mdonav;
            
            micon = [[[subString getInfomation:@"src=\".*?\""] getInfomation:@"\".*?\""] mutableCopy];
            micon = [micon deleteString:@[@"\""]];
            
            mname = [[[subString getInfomation:@"src=\".*?<"] getInfomation:@">.*?<"] mutableCopy];
            mname = [mname deleteString:@[@"\"", @" ", @">", @"<", @"\n"]];
            
            NSArray *subArray = [subString getInfomations:@"10px\">.*?</div>"];
            
            mtimes = [[subArray[0] getInfomation:@">.*?<"] mutableCopy];
            mtimes = [mtimes deleteString:@[@">", @"<"]];
            
            mwin = [[subArray[1] getInfomation:@">.*?<"] mutableCopy];
            mwin = [mwin deleteString:@[@">", @"<"]];
            
            mdonav = [[subString getInfomation:@"hero.*?'"] mutableCopy];
            mdonav = [mdonav deleteString:@[@"'"]];
            
            [mdonav insertString:@"/" atIndex:0];
            
            HeroInfomation *item = [HeroInfomation new];
            item.icon = micon;
            item.name = mname;
            item.times = mtimes;
            item.win = mwin;
            item.donav = mdonav;
            [_dataArray addObject:item];
        }
        
        [_tableView.header endRefreshing];
        [_tableView reloadData];
        
    } failure:^(NSError *error) {
       HLAlertView *alertView = [[HLAlertView alloc] initWithtitle:@"网络不好,请稍后重试" target:self.view];
        [alertView show];
        [_tableView.header endRefreshing];

    } progress:^(NSProgress *progress) {
        
    }];
}

- (void)refreshTitle
{
    [_titleIcon sd_setImageWithURL:[NSURL URLWithString:self.titleDataArray[0]]];
    _titleNameLabel.text = self.titleDataArray[1];
    _titleSecondLabel.text = self.titleDataArray[2];
    _titleOtherLabel.text = self.titleDataArray[3];
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 60;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    return _dataArray.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    HLHeroAndProductTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"HeroAndItemCell"];
    if (!cell) {
        cell= [[NSBundle mainBundle]loadNibNamed:@"HLHeroAndProductTableViewCell" owner:nil options:nil].lastObject;
        
        HeroInfomation *hero = (HeroInfomation *)_dataArray[indexPath.row];
        
        [cell.iconView sd_setImageWithURL:[NSURL URLWithString:hero.icon]];
        cell.nameLable.text = hero.name;
        cell.timesLable.text = hero.times;
        cell.winLable.text = hero.win;
        CGFloat progress = [hero.win floatValue];
        
        cell.winProgress.progress = progress / 100.0;
        
        cell.winLable.frame = CGRectMake(WIDTH * 2 / 3, 15, WIDTH / 3, 20);
        
        cell.timesLable.frame = CGRectMake(WIDTH / 3, 5, WIDTH / 3, 40);
        cell.winProgress.frame = CGRectMake(WIDTH * 2 / 3 + 5, 35, WIDTH / 3 - 10, 20);
        cell.backgroundColor = [UIColor clearColor];
    }
    

    
    return cell;
}



/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
