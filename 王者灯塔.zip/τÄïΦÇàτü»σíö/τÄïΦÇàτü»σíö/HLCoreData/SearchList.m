//
//  SearchList.m
//  王者灯塔
//
//  Created by tarena on 16/1/28.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "SearchList.h"

@implementation SearchList

// Insert code here to add functionality to your managed object subclass

@end
