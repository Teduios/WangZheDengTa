//
//  NewsHeaderTableViewCell.h
//  王者灯塔
//
//  Created by tarena on 16/1/10.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NewsHeaderTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIScrollView *headerScrollView;
@property (weak, nonatomic) IBOutlet UILabel *headerLable;
@property (weak, nonatomic) IBOutlet UIPageControl *headerPageController;

@end
