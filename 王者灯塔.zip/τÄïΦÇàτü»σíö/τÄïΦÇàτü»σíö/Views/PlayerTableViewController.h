//
//  PlayerTableViewController.h
//  王者灯塔
//
//  Created by tarena on 16/1/3.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PlayerTableViewController : UITableViewController

@end
