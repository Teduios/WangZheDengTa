//
//  NewsTableViewController.m
//  王者灯塔
//
//  Created by tarena on 16/1/3.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "NewsTableViewController.h"
#import "HLNewsCategoryTableTableViewController.h"
#import "HLNetModle.h"
#import "NSString+ParseURLString.h"
#import "NewsModle.h"
#import "NewsHeaderTableViewCell.h"
#import "NewsContentTableViewCell.h"
#import "MJRefresh.h"
#import "UIImageView+WebCache.h"
#import "Masonry.h"
#import "HLDetailViewController.h"
#import "HLAlertView.h"
#import "HLAlertViewChoose.h"

#define URLSTINGARRAY @[@"http://lol.data.shiwan.com/getArticleListImprove/?cid_rel=207&page=%d",@"http://lol.data.shiwan.com/getArticleListImprove/?cid_rel=211&page=%d",@"http://lol.data.shiwan.com/getArticleListImprove/?cid_rel=216&page=%d",@"http://lol.data.shiwan.com/getArticleListImprove/?cid_rel=213&page=%d",@"http://lol.data.shiwan.com/getArticleListImprove/?cid_rel=210&page=%d"]

@interface NewsTableViewController ()<HLNewsControllerDelegate>
@property(nonatomic,strong)HLNewsCategoryTableTableViewController*newsController;
@property(nonatomic,strong)UIButton*leftButton;

@property(nonatomic,assign)NSInteger page;

@property(nonatomic,strong)NSMutableArray* dataArray;
@property(nonatomic,strong)NSMutableDictionary* dataDictionary;
@property(nonatomic,strong)UIProgressView* progress;
@property(nonatomic,strong)NSMutableArray* titleLableArray;
@property(nonatomic,strong)NewsHeaderTableViewCell*headerCell;
@property(nonatomic,strong)NSTimer*timer;
@property(nonatomic,assign)NSInteger flag;

@end

@implementation NewsTableViewController

#pragma mark - 懒加载



-(NSTimer *)timer
{
    if (!_timer) {
        _timer=[NSTimer new];
    }
    return _timer;
}

-(NSMutableArray *)dataArray
{
    if (!_dataArray) {
        _dataArray=[NSMutableArray array];
    }
    return _dataArray;
}

-(NSMutableDictionary *)dataDictionary
{
    if (!_dataDictionary) {
        _dataDictionary=[NSMutableDictionary dictionary];
    }
    return _dataDictionary;
}

-(NSMutableArray *)titleLableArray
{
    if (!_titleLableArray) {
        _titleLableArray=[NSMutableArray array];
    }
    return _titleLableArray;
}

-(UIProgressView *)progress
{
    if (!_progress) {
        _progress=[[UIProgressView alloc]init];
    }
    return _progress;
}

-(HLNewsCategoryTableTableViewController *)newsController
{
    if (!_newsController) {
        _newsController=[HLNewsCategoryTableTableViewController new];
    }
    return  _newsController;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.leftButton=[UIButton new];
    [self.leftButton setImage:[UIImage imageNamed:@"down.png"] forState:UIControlStateNormal];
    [self.leftButton setImage:[UIImage imageNamed:@"up.png"] forState:UIControlStateHighlighted];
    [self.leftButton setTitle:@"选择栏" forState:UIControlStateNormal];
    [self.leftButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.leftButton setTitleColor:[UIColor orangeColor] forState:UIControlStateHighlighted];
    self.leftButton.titleLabel.font=[UIFont systemFontOfSize:16];
    self.leftButton.frame=CGRectMake(0, 0, 90, 50);
    [self.leftButton addTarget:self action:@selector(gotoMenu) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.leftBarButtonItem=[[UIBarButtonItem alloc]initWithCustomView:self.leftButton];

    self.page=1;
    self.flag=0;
    /**一堆自定义方法*/
    [self createToTopButton];
    [self createButton];
    [self refreshContent];
    [self.tableView registerNib:[UINib nibWithNibName:@"NewsContentTableViewCell" bundle:nil] forCellReuseIdentifier:@"contentCell"];
    [self.tableView registerNib:[UINib nibWithNibName:@"NewsHeaderTableViewCell" bundle:nil] forCellReuseIdentifier:@"titleCell"];
    
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self.dataArray removeAllObjects];
    [self.dataDictionary removeAllObjects];
    [self refreshContent];
    [self.tableView reloadData];
}

-(void)inputViewController:(HLNewsCategoryTableTableViewController *)vc inputFlag:(NSInteger)flag
{
    self.flag=flag;
   // NSLog(@"%ld",(long)self.flag);
}

-(void)createButton
{
    UIButton*button=[UIButton new];
    [button setBackgroundColor:[UIColor orangeColor]];
    [button setTitle:@"下拉页面刷新O(∩_∩)O哟~~" forState:UIControlStateNormal];
    button.titleLabel.tintColor=[UIColor blackColor];
    button.userInteractionEnabled=NO;
    [self.view addSubview:button];
    [button mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.view.mas_left).mas_equalTo(0);
        make.top.mas_equalTo(self.view.mas_top).mas_equalTo(0);
        make.width.mas_equalTo(self.view.mas_width);
        make.height.mas_equalTo(35);
    }];

}

#pragma mark - ButtonTarget
-(void)gotoMenu
{
    self.newsController.delegate=self;
    [self presentViewController:self.newsController animated:YES completion:nil];
}

-(void)refreshContent
{
    self.tableView.header=[MJRefreshNormalHeader headerWithRefreshingTarget:self refreshingAction:@selector(headerRefresh)];
    self.tableView.footer=[MJRefreshAutoNormalFooter footerWithRefreshingTarget:self refreshingAction:@selector(upRefresh)];
    [self.tableView.header beginRefreshing];
    
}

-(void)headerRefresh
{
    self.page=1;
    [self getDataByFlag:self.flag page:self.page];
}

-(void)getDataByFlag:(NSInteger)flag page:(NSInteger)page
{
    for (int i=0; i<[URLSTINGARRAY count]; i++) {
        [HLNetModle apiGetHttpURL:[NSString stringWithFormat:URLSTINGARRAY[i],page] success:^(id Object) {
            [self.dataDictionary setValue:Object forKey:[NSString stringWithFormat:@"%d",i]];
            
            if ([self.dataDictionary count]==[URLSTINGARRAY count]) {
                [self refreshTableView:flag];
            }
            
        } failure:^(NSError *error) {
            NSLog(@"加载失败");
            HLAlertView *alertView = [[HLAlertView alloc] initWithtitle:@"网络不好,请稍后重试" target:self.view];
            [alertView show];
            [self.tableView.header endRefreshing];
            [self.tableView.footer endRefreshing];
            
        } progress:^(NSProgress *progress) {
            
        }];
    }
}

-(void)refreshTableView:(NSInteger)flag
{
    NSArray*titleArray=self.dataDictionary[[NSString stringWithFormat:@"%ld",(long)flag]][@"recomm"];
    NSMutableArray* titleMutableArray=[NSMutableArray array];
    for (NSDictionary*dic in titleArray) {
        NewsModle* modle=[NewsModle new];
        modle.title=dic[@"name"];
        modle.icon=dic[@"ban_img"];
        modle.ID=dic[@"article_id"];
        modle.comment=dic[@"comment_count"];
        [titleMutableArray addObject:modle];
    }
    [self.dataArray addObject:titleMutableArray];
    NSArray*array=self.dataDictionary[[NSString stringWithFormat:@"%ld",(long)flag]][@"result"];
    for (NSDictionary*subDic in array) {
        NewsModle*modle=[[NewsModle alloc]initWithDictionary:subDic] ;
        [self.dataArray addObject:modle];
        
    }
    [self.tableView.header endRefreshing];
    [self.tableView reloadData];
}

-(void)upRefresh
{
    [self getMoreData:[NSString stringWithFormat:URLSTINGARRAY[self.flag],++(self.page)]];
}

-(void)getMoreData:(NSString*)URL
{
    [HLNetModle apiGetHttpURL:URL success:^(id Object) {
        for (NSDictionary*resultDic in Object[@"result"]) {
            NewsModle*modle=[[NewsModle alloc]initWithDictionary:resultDic];
            [self.dataArray addObject:modle];
        }
        [self.tableView.footer endRefreshing];
        [self.tableView reloadData];
        
    } failure:^(NSError *error) {
        /**加载失败*/
        NSLog(@"加载失败");
        HLAlertView *alertView = [[HLAlertView alloc] initWithtitle:@"网络不好,请稍后重试" target:self.view];
        [alertView show];
    } progress:^(NSProgress *progress) {
 
    }];
}

-(void)createToTopButton
{
    
}











#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {

    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    return [self.dataArray count];
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row==0) {
        return 150;
    }else{
        return 105;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.row==0) {
        NewsHeaderTableViewCell*cell=[tableView dequeueReusableCellWithIdentifier:@"titleCell" forIndexPath:indexPath];
        
        [self createCell:cell];
        return cell;
    }else{
    NewsModle *model = self.dataArray[indexPath.row];
    NewsContentTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"contentCell" forIndexPath:indexPath];
    cell.titleLable.text = model.title;
    [cell.iconImageView sd_setImageWithURL:[NSURL URLWithString:model.icon]];
    cell.shortLable.text = model.short_title;
        cell.idLable.text=[NSString stringWithFormat:@"%@",model.comment];
    return cell;
    }
}


-(void)createCell:(NewsHeaderTableViewCell*)cell
{
    cell.headerScrollView.contentSize=CGSizeMake(self.view.bounds.size.width*([self.dataArray[0] count]+1), 150);
    cell.headerScrollView.contentOffset=CGPointMake(0, 0);
    cell.headerScrollView.scrollEnabled=NO;

    while ([[cell.headerScrollView subviews]lastObject]!=nil) {
        [[[cell.headerScrollView subviews] lastObject] removeFromSuperview];
    }
    
    for (int i=0; i<[self.dataArray[0] count]; i++) {
        UIImageView*imageView=[[UIImageView alloc]initWithFrame:CGRectMake(i*self.view.bounds.size.width, 0, self.view.bounds.size.width, 150)];
        NewsModle* modal=self.dataArray[0][i];
        [imageView sd_setImageWithURL:[NSURL URLWithString:[modal.icon parseURLString]]];
        [cell.headerScrollView addSubview:imageView];
        [self.titleLableArray addObject:modal.title];
        imageView.tag=10+i;
        UITapGestureRecognizer* gesture=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(imageClick:)];
        gesture.numberOfTapsRequired=1;
        gesture.numberOfTouchesRequired=1;
        imageView.userInteractionEnabled=YES;
        [imageView addGestureRecognizer:gesture];
        
    }
    UIImageView*firstImageView=[[UIImageView alloc]initWithFrame:CGRectMake(self.view.bounds.size.width*([self.dataArray[0] count]), 0, self.view.bounds.size.width, 150)];
    firstImageView.tag=10;
    NewsModle* modal=[self.dataArray[0] firstObject];
    [firstImageView sd_setImageWithURL:[NSURL URLWithString:[modal.icon parseURLString]]];
    UITapGestureRecognizer* gesture=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(imageClick:)];
    gesture.numberOfTapsRequired=1;
    gesture.numberOfTouchesRequired=1;
    firstImageView.userInteractionEnabled=YES;
    [firstImageView addGestureRecognizer:gesture];
    [cell.headerScrollView addSubview:firstImageView];
    
    cell.headerLable.text=self.titleLableArray[0];
    cell.headerLable.textAlignment=NSTextAlignmentLeft;
    [self.timer invalidate];
    self.timer=[NSTimer scheduledTimerWithTimeInterval:2 target:self selector:@selector(rollScrollView:) userInfo:nil repeats:YES];
    cell.headerPageController.numberOfPages=[self.dataArray[0] count];
    self.headerCell=cell;

}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row>0) {
        NewsModle* modle=self.dataArray[indexPath.row];
        NSString*url=[NSString stringWithFormat:@"http://lol.data.shiwan.com/getArticleInfo/loldata?article_id=%@",modle.ID];
        HLDetailViewController*detailVC=[[HLDetailViewController alloc]initWithNibName:@"HLDetailViewController" bundle:nil];
        detailVC.URL=url;
        [self presentViewController:detailVC animated:YES completion:nil];
    }
    
}

-(void)rollScrollView:(NSTimer*)timer
{
    CGFloat x = _headerCell.headerScrollView.contentOffset.x;
    NSInteger count = [_dataArray.firstObject count];
    
    if (x == count * self.view.bounds.size.width)
    {
        _headerCell.headerScrollView.contentOffset = CGPointMake(0, 0);
        x = 0;
    }
    
    
    [UIView animateWithDuration:1 animations:^{
        if (x == (count - 1) * self.view.bounds.size.width)
        {
            _headerCell.headerPageController.currentPage = 0;
        }
        else
        {
            _headerCell.headerPageController.currentPage++;
        }
        _headerCell.headerScrollView.contentOffset = CGPointMake(x + self.view.bounds.size.width, 0);
        _headerCell.headerLable.text = _titleLableArray[_headerCell.headerPageController.currentPage];
    }];
    
}

-(void)imageClick:(UITapGestureRecognizer*)gesture
{
    NewsModle *model = self.dataArray[0][gesture.view.tag-10];
    NSString *url = [NSString stringWithFormat:@"http://lol.data.shiwan.com/getArticleInfo/loldata?article_id=%@",model.ID];
    HLDetailViewController*detailVC=[[HLDetailViewController alloc]initWithNibName:@"HLDetailViewController" bundle:nil];
    detailVC.URL=url;
    [self presentViewController:detailVC animated:YES completion:nil];
}

/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
