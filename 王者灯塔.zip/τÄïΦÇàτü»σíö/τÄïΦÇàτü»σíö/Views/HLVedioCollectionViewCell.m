//
//  HLVedioCollectionViewCell.m
//  王者灯塔
//
//  Created by tarena on 16/1/16.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "HLVedioCollectionViewCell.h"

@implementation HLVedioCollectionViewCell

- (void)awakeFromNib {
    // Initialization code
}

@end
