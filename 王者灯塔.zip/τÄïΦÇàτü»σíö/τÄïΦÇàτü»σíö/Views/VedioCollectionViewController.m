//
//  VedioCollectionViewController.m
//  王者灯塔
//
//  Created by tarena on 16/1/3.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "VedioCollectionViewController.h"

#import "HLVedioCollectionViewCell.h"
#import "MJRefresh.h"
#import "VedioModle.h"
#import "HLNetModle.h"
#import "AFNetworking.h"
#import "UIImageView+WebCache.h"
#import <MediaPlayer/MediaPlayer.h>
#import "Masonry.h"
#import "HLAlertViewChoose.h"
#import "HLAlertView.h"

#define URL_VIDEO @"http://box.dwstatic.com/apiVideoesNormalDuowan.php?action=l&p=%lu&v=140&tag=jingjieveryday"
#define URL_VIDEO_DETAIL @"http://box.dwstatic.com/apiVideoesNormalDuowan.php?action=f&vid=%@"

@interface VedioCollectionViewController ()

@property(nonatomic,strong)NSMutableArray*dataArray;
@property(nonatomic,strong)NSMutableArray*imageArray;
@property(nonatomic,assign)NSInteger page;

@end

@implementation VedioCollectionViewController

-(NSMutableArray *)dataArray{
    if (!_dataArray) {
        _dataArray=[NSMutableArray array];
    }
    return _dataArray;
}

-(NSMutableArray *)imageArray
{
    if (!_imageArray) {
        _imageArray=[NSMutableArray array];
    }
    return _imageArray;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title=@"灯塔视频";

    // Uncomment the following line to preserve selection between presentations
    // self.clearsSelectionOnViewWillAppear = NO;
    self.collectionView.backgroundColor=[UIColor clearColor];
    // Register cell classes
    [self.collectionView registerNib:[UINib nibWithNibName:@"HLVedioCollectionViewCell" bundle:nil] forCellWithReuseIdentifier:@"item"];
    UICollectionViewFlowLayout *layout = [UICollectionViewFlowLayout new];
    //itemSize
    layout.itemSize = CGSizeMake(320, 200);
    //inset
    layout.sectionInset = UIEdgeInsetsMake(15, 15, 15, 15);
    [self.collectionView initWithFrame:CGRectZero collectionViewLayout:layout];
    self.collectionView.backgroundColor=[UIColor whiteColor];
    self.collectionView.mj_header=[MJRefreshNormalHeader  headerWithRefreshingTarget:self refreshingAction:@selector(headerRefresh)];
    self.collectionView.mj_footer=[MJRefreshAutoNormalFooter footerWithRefreshingTarget:self refreshingAction:@selector(footerRefresh)];
    [self.collectionView.mj_header beginRefreshing];
    //设置背景
    self.collectionView.backgroundView=[[UIImageView alloc]initWithImage:[UIImage imageNamed:@"5.png"]];
    
    
    // Do any additional setup after loading the view.
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    self.imageArray=nil;
    self.dataArray=nil;
    self.page=1;
    [self getDataByPage:1];
    [self.collectionView reloadData];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Data

-(void)headerRefresh
{
    self.imageArray=nil;
    self.dataArray=nil;
    self.page=1;
    [self getDataByPage:1];
}

-(void)footerRefresh
{
    [self getDataByPage:++self.page];
}

-(void)getDataByPage:(NSInteger)page
{
    [HLNetModle apiGetHttpURL:[NSString stringWithFormat:URL_VIDEO,page] success:^(id Object) {
        NSMutableArray*mutableArray=[NSMutableArray array];
        for (int i=0; i<[Object count]; i++) {
            NSDictionary*dic=Object[i];
            VedioModle*modle=[VedioModle new];
            [modle setValuesForKeysWithDictionary:dic];
            [self.dataArray addObject:modle];
            [mutableArray addObject:modle];
            
        }
        for (VedioModle*modle in mutableArray) {
            UIImageView*imageView=[[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 160, 225)];
            [imageView sd_setImageWithURL:[NSURL URLWithString:[modle.cover_url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]] completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
                [self.imageArray addObject:imageView.image];
                if (self.imageArray.count==self.dataArray.count) {
                    [self.collectionView.mj_footer endRefreshing];
                    [self.collectionView.mj_header endRefreshing];
                    [self.collectionView reloadData];
                }
            }];
        }
        
        
        
        
    } failure:^(NSError *error) {
        [self.collectionView.mj_header endRefreshing];
      HLAlertView *alertView = [[HLAlertView alloc] initWithtitle:@"网络不好,请稍后重试" target:self.view];
        [alertView show];
        NSLog(@"失败");
    } progress:^(NSProgress *progress) {
        
    }];
}



/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

#pragma mark <UICollectionViewDataSource>

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {

    return 1;
}


- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {

    return self.dataArray.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    HLVedioCollectionViewCell*cell=[collectionView dequeueReusableCellWithReuseIdentifier:@"item" forIndexPath:indexPath];
    cell.backgroundColor=[UIColor lightGrayColor];
    cell.cellImageView.image=self.imageArray[indexPath.row];
    VedioModle*modle=self.dataArray[indexPath.row];
    cell.cellTitleLable.text=modle.title;
    cell.cellTimeLable.text=[NSString stringWithFormat:@"%ld:%ld ",modle.video_length/60,modle.video_length%60];
    // Configure the cell
    UIButton*button=[UIButton new];
    [button setBackgroundImage:[UIImage imageNamed:@"videoIcon@2x.png"] forState:0];
    button.backgroundColor=[UIColor clearColor];
    [cell.contentView addSubview:button];
    [button mas_makeConstraints:^(MASConstraintMaker *make) {
        make.center.mas_equalTo(cell.contentView);
    }];
    button.userInteractionEnabled=NO;
    return cell;
}

#pragma mark <UICollectionViewDelegate>

-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    [HLNetModle apiGetHttpURL:[NSString stringWithFormat:URL_VIDEO_DETAIL,[self.dataArray[indexPath.row] vid]] success:^(id Object) {
        NSString* url=[Object[@"result"][@"items"][@"1000"][@"transcode"][@"urls"] firstObject];
        MPMoviePlayerViewController* player=[[MPMoviePlayerViewController alloc]initWithContentURL:[NSURL URLWithString:[url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]]];
        AFHTTPSessionManager* manager=[AFHTTPSessionManager manager];
        [manager.reachabilityManager setReachabilityStatusChangeBlock:^(AFNetworkReachabilityStatus status) {
            if (status == AFNetworkReachabilityStatusReachableViaWWAN)
            {
                HLAlertViewChoose *alert = [[HLAlertViewChoose alloc] initWithtitle:@"当前为非WIFI环境,是否继续?" target:self.view];
                alert.btnClick = ^(BOOL go)
                {
                    if (go)
                    {
                        [self presentMoviePlayerViewControllerAnimated:player];
                    }
                };
            }
            else if (status == AFNetworkReachabilityStatusReachableViaWiFi)
            {
                [self presentMoviePlayerViewControllerAnimated:player];
            }
            else if (status == AFNetworkReachabilityStatusNotReachable || status == AFNetworkReachabilityStatusUnknown)
            {
                HLAlertView *alertView = [[HLAlertView alloc] initWithtitle:@"网络不好,请稍后重试" target:self.view];
                [alertView show];
            }

        }];
        [manager.reachabilityManager startMonitoring];
        
    } failure:^(NSError *error) {
        HLAlertView *alertView = [[HLAlertView alloc] initWithtitle:@"网络不好,请稍后重试" target:self.view];
        [alertView show];
    } progress:^(NSProgress *progress) {
        
    }];
}

/*
// Uncomment this method to specify if the specified item should be highlighted during tracking
- (BOOL)collectionView:(UICollectionView *)collectionView shouldHighlightItemAtIndexPath:(NSIndexPath *)indexPath {
	return YES;
}
*/

/*
// Uncomment this method to specify if the specified item should be selected
- (BOOL)collectionView:(UICollectionView *)collectionView shouldSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    return YES;
}
*/

/*
// Uncomment these methods to specify if an action menu should be displayed for the specified item, and react to actions performed on the item
- (BOOL)collectionView:(UICollectionView *)collectionView shouldShowMenuForItemAtIndexPath:(NSIndexPath *)indexPath {
	return NO;
}

- (BOOL)collectionView:(UICollectionView *)collectionView canPerformAction:(SEL)action forItemAtIndexPath:(NSIndexPath *)indexPath withSender:(id)sender {
	return NO;
}

- (void)collectionView:(UICollectionView *)collectionView performAction:(SEL)action forItemAtIndexPath:(NSIndexPath *)indexPath withSender:(id)sender {
	
}
*/

@end
