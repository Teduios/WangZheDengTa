//
//  HLPlayerTableViewCell.m
//  王者灯塔
//
//  Created by tarena on 16/1/21.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "HLPlayerTableViewCell.h"

#define WIDTH [UIScreen mainScreen].bounds.size.width

@implementation HLPlayerTableViewCell

- (void)awakeFromNib {
    // Initialization code
    self.iconView = [[UIImageView alloc] init];
    self.iconView.layer.cornerRadius = 20;
    self.iconView.layer.masksToBounds = YES;
    self.winProgress.trackTintColor = [UIColor lightGrayColor];
    self.winProgress.progressTintColor = [UIColor orangeColor];
    self.scoreProgress.progressTintColor = [UIColor orangeColor];
    self.scoreProgress.trackTintColor = [UIColor lightGrayColor];
    
    self.iconView.frame = CGRectMake(5, 5, 40, 40);
//    self.nameLable.frame = CGRectMake(30, 5, WIDTH / 4 , 20);
//    self.gradeLable.frame = CGRectMake(30, 25, WIDTH / 4, 20);
//    
//    self.winLable.frame = CGRectMake(WIDTH / 2+25, 5, WIDTH / 4, 20);
//    self.winProgress.frame = CGRectMake(WIDTH / 2 + 15, 25, WIDTH / 4 - 10, 20);
//    
//    self.scoreLable.frame = CGRectMake(WIDTH * 3  / 4+25, 5, WIDTH / 4, 20);
//    self.scoreProgress.frame = CGRectMake(WIDTH * 3  / 4 + 15, 25, WIDTH / 4 - 10, 20);
        [self.contentView addSubview:self.iconView];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
