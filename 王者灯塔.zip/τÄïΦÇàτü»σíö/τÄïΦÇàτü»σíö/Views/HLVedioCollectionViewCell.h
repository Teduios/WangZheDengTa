//
//  HLVedioCollectionViewCell.h
//  王者灯塔
//
//  Created by tarena on 16/1/16.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HLVedioCollectionViewCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UIImageView *cellImageView;
@property (weak, nonatomic) IBOutlet UILabel *cellTitleLable;
@property (weak, nonatomic) IBOutlet UILabel *cellTimeLable;

@end
