//
//  HLHeroAndProductTableViewCell.m
//  王者灯塔
//
//  Created by tarena on 16/1/22.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "HLHeroAndProductTableViewCell.h"

#define WIDTH [[UIScreen mainScreen] bounds].size.width
@implementation HLHeroAndProductTableViewCell

- (void)awakeFromNib {
    // Initialization code
    self.iconView.layer.cornerRadius = 15;
    self.iconView.layer.masksToBounds = YES;
    self.winProgress.progressTintColor = [UIColor orangeColor];
    self.winProgress.trackTintColor = [UIColor lightGrayColor];
    
//    self.iconView.frame = CGRectMake(5, 5, 40, 40);
//    self.nameLable.frame = CGRectMake(45, 5, WIDTH / 3 - 45, 40);
//    
//    self.winLable.frame = CGRectMake(WIDTH / 3, 15, WIDTH / 3, 20);
//    
//    self.timesLable.frame = CGRectMake(WIDTH * 2  / 3, 5, WIDTH / 3, 40);
//    self.winProgress.frame = CGRectMake(WIDTH / 3 + 5, 35, WIDTH / 3 - 10, 20);
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    

    // Configure the view for the selected state
}

@end
