//
//  BaseCell.m
//  王者灯塔
//
//  Created by tarena on 16/1/21.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "BaseCell.h"

#define WIDTH [[UIScreen mainScreen] bounds].size.width
@implementation BaseCell

- (void)awakeFromNib {
    // Initialization code
    self.firstLable.frame = CGRectMake(0, 0, WIDTH / 4, 40);
    self.icon = [[UIImageView alloc] initWithFrame:CGRectMake(5, 5, 30, 30)];
    self.icon.layer.cornerRadius = 15;
    self.icon.layer.masksToBounds = YES;
    self.icon.hidden = YES;
    self.nameLabel = [[UILabel alloc] initWithFrame:CGRectMake(40, 0, WIDTH / 4 - 40, 40)];
    self.nameLabel.textColor = [UIColor blackColor];
    self.nameLabel.font = [UIFont systemFontOfSize:11];
    self.nameLabel.hidden = YES;
    self.firstLable.userInteractionEnabled = YES;
    [self.firstLable addSubview:self.icon];
    [self.firstLable addSubview:self.nameLabel];
   
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
