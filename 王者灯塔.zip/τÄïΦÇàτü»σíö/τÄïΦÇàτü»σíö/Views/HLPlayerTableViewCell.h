//
//  HLPlayerTableViewCell.h
//  王者灯塔
//
//  Created by tarena on 16/1/21.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HLPlayerTableViewCell : UITableViewCell
@property(nonatomic,strong)UIImageView* iconView;

@property (weak, nonatomic) IBOutlet UILabel *nameLable;
@property (weak, nonatomic) IBOutlet UILabel *gradeLable;
@property (weak, nonatomic) IBOutlet UILabel *winLable;
@property (weak, nonatomic) IBOutlet UILabel *scoreLable;
@property (weak, nonatomic) IBOutlet UIProgressView *winProgress;
@property (weak, nonatomic) IBOutlet UIProgressView *scoreProgress;


@end
