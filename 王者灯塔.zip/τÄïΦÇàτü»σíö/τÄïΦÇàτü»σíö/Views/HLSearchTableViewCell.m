//
//  HLSearchTableViewCell.m
//  王者灯塔
//
//  Created by tarena on 16/1/28.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "HLSearchTableViewCell.h"

#define WIDTH [UIScreen mainScreen].bounds.size.width

@implementation HLSearchTableViewCell

- (void)awakeFromNib {
    // Initialization code
   
    self.icon.layer.cornerRadius = 20;
    self.icon.layer.masksToBounds = YES;
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
