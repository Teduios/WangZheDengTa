//
//  HLHeroAndProductTableViewCell.h
//  王者灯塔
//
//  Created by tarena on 16/1/22.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HLHeroAndProductTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *iconView;
@property (weak, nonatomic) IBOutlet UILabel *nameLable;
@property (weak, nonatomic) IBOutlet UILabel *winLable;
@property (weak, nonatomic) IBOutlet UILabel *timesLable;
@property (weak, nonatomic) IBOutlet UIProgressView *winProgress;



@end
