//
//  PlayerTableViewController.m
//  王者灯塔
//
//  Created by tarena on 16/1/3.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "PlayerTableViewController.h"
#import "HLNewsCategoryTableTableViewController.h"
#import "HLNetModle.h"
#import "NSString+ParseURLString.h"
#import "NewsModle.h"
#import "NewsHeaderTableViewCell.h"
#import "NewsCategoryTableViewCell.h"
#import "MJRefresh.h"
#import "UIImageView+WebCache.h"
#import "Masonry.h"
#import "HLDetailViewController.h"

#define HLStrategyUrlString @"http://lol.data.shiwan.com/getArticleListImprove/?cid_rel=214&page=%d"

@interface PlayerTableViewController ()

@property(nonatomic,assign)NSInteger page;
@property(nonatomic,strong)NSMutableArray* dataArray;
@property(nonatomic,strong)NSMutableDictionary* dataDictionary;
@property(nonatomic,strong)NSMutableArray* titleLableArray;
@property(nonatomic,strong)NewsHeaderTableViewCell*headerCell;
@property(nonatomic,strong)NSTimer*timer;
@end

@implementation PlayerTableViewController

#pragma mark - 懒加载

-(NSMutableArray *)dataArray
{
    if (!_dataArray) {
        _dataArray=[NSMutableArray array];
    }
    return _dataArray;
}

-(NSMutableDictionary *)dataDictionary
{
    if (!_dataDictionary) {
        _dataDictionary=[NSMutableDictionary dictionary];
    }
    return _dataDictionary;
}

-(NSMutableArray *)titleLableArray
{
    if (!_titleLableArray) {
        _titleLableArray=[NSMutableArray array];
    }
    return _titleLableArray;
}

-(NewsHeaderTableViewCell*)headerCell
{
    if (!_headerCell) {
        _headerCell=[NewsHeaderTableViewCell new];
    }
    return _headerCell;
}

-(NSTimer *)timer
{
    if (!_timer) {
        _timer=[NSTimer new];
    }
    return _timer;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title=@"灯塔攻略";
    
    self.page=1;
    [self.tableView registerNib:[UINib nibWithNibName:@"NewsHeaderTableViewCell" bundle:nil] forCellReuseIdentifier:@"titleCell"];
    [self.tableView registerNib:[UINib nibWithNibName:@"NewsCategoryTableViewCell" bundle:nil] forCellReuseIdentifier:@"contentCell"];
    [self refreshContent];
//    [self createButton];
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self.dataArray removeAllObjects];
    [self.dataDictionary removeAllObjects];
    [self refreshContent];
    [self.tableView reloadData];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

//-(void)createButton
//{
//    UIButton*button=[UIButton new];
//    [button setBackgroundColor:[UIColor orangeColor]];
//    [button setTitle:@"下拉页面刷新O(∩_∩)O哟~~" forState:UIControlStateNormal];
//    button.titleLabel.tintColor=[UIColor blackColor];
//    button.userInteractionEnabled=NO;
//    [self.view addSubview:button];
//    [button mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.left.mas_equalTo(self.view.mas_left).mas_equalTo(0);
//        make.top.mas_equalTo(self.view.mas_top).mas_equalTo(0);
//        make.width.mas_equalTo(self.view.mas_width);
//        make.height.mas_equalTo(35);
//    }];
//    
//}

-(void)refreshContent
{
    self.tableView.header=[MJRefreshNormalHeader headerWithRefreshingTarget:self refreshingAction:@selector(headerRefresh)];
    self.tableView.footer=[MJRefreshAutoNormalFooter footerWithRefreshingTarget:self refreshingAction:@selector(upRefresh)];
    [self.tableView.header beginRefreshing];
}

-(void)headerRefresh
{
    self.page=1;
    [self getDataByPage:self.page];
}

-(void)getDataByPage:(NSInteger)page
{

        [HLNetModle apiGetHttpURL:[NSString stringWithFormat:HLStrategyUrlString,(int)page] success:^(id Object) {
            
            [self.dataDictionary setDictionary:Object];
            NSArray*titleArray=self.dataDictionary[@"recomm"];
            NSMutableArray* titleMutableArray=[NSMutableArray array];
            for (NSDictionary*dic in titleArray) {
                NewsModle* modle=[NewsModle new];
                modle.title=dic[@"name"];
                modle.icon=dic[@"ban_img"];
                modle.ID=dic[@"article_id"];
                modle.comment=dic[@"comment_count"];
                [titleMutableArray addObject:modle];
            }
            [self.dataArray addObject:titleMutableArray];
            NSArray*array=self.dataDictionary[@"result"];
            for (NSDictionary*subDic in array) {
                NewsModle*modle=[[NewsModle alloc]initWithDictionary:subDic] ;
                [self.dataArray addObject:modle];
                
            }
            [self.tableView.header endRefreshing];
            [self.tableView reloadData];
            
        } failure:^(NSError *error) {
            NSLog(@"加载失败");
            [self.tableView.header endRefreshing];
            [self.tableView.footer endRefreshing];
            
        } progress:^(NSProgress *progress) {
            
        }];
    
}


-(void)upRefresh
{
   [self getMoreData:[NSString stringWithFormat:HLStrategyUrlString,(int)++self.page]];
}
    
-(void)getMoreData:(NSString*)URL
{
    [HLNetModle apiGetHttpURL:URL success:^(id Object) {
            for (NSDictionary*resultDic in Object[@"result"]) {
                NewsModle*modle=[[NewsModle alloc]initWithDictionary:resultDic];
                [self.dataArray addObject:modle];
        }
        [self.tableView.footer endRefreshing];
        [self.tableView reloadData];
            
    } failure:^(NSError *error) {
            /**加载失败*/
            NSLog(@"加载失败");
    } progress:^(NSProgress *progress) {
            
    }];
}


#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {

    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    return self.dataArray.count;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row==0) {
        return 150;
    }else{
        return 160;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.row==0) {
        NewsHeaderTableViewCell*cell=[tableView dequeueReusableCellWithIdentifier:@"titleCell" forIndexPath:indexPath];
        [self createCell:cell];
        return cell;
    }else{
        NewsModle *model = self.dataArray[indexPath.row];
        NewsCategoryTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"contentCell" forIndexPath:indexPath];
        cell.titleLable.text = model.title;
        cell.contentLable.text = model.short_title;
        return cell;
    }
}

-(void)createCell:(NewsHeaderTableViewCell*)cell
{
    cell.headerScrollView.contentSize=CGSizeMake(self.view.bounds.size.width*([self.dataArray[0] count]+1), 150);
    cell.headerScrollView.contentOffset=CGPointMake(0, 0);
    cell.headerScrollView.scrollEnabled=NO;
    
    while ([[cell.headerScrollView subviews]lastObject]!=nil) {
        [[[cell.headerScrollView subviews] lastObject] removeFromSuperview];
    }
    
    for (int i=0; i<[self.dataArray[0] count]; i++) {
        UIImageView*imageView=[[UIImageView alloc]initWithFrame:CGRectMake(i*self.view.bounds.size.width, 0, self.view.bounds.size.width, 150)];
        NewsModle* modal=self.dataArray[0][i];
        [imageView sd_setImageWithURL:[NSURL URLWithString:[modal.icon parseURLString]]];
        [cell.headerScrollView addSubview:imageView];
        [self.titleLableArray addObject:modal.title];
        imageView.tag=i;
        UITapGestureRecognizer* gesture=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(imageClick:)];
        gesture.numberOfTapsRequired=1;
        gesture.numberOfTouchesRequired=1;
        imageView.userInteractionEnabled=YES;
        [imageView addGestureRecognizer:gesture];
        
    }
    UIImageView*firstImageView=[[UIImageView alloc]initWithFrame:CGRectMake(self.view.bounds.size.width*([self.dataArray[0] count]), 0, self.view.bounds.size.width, 150)];
    firstImageView.tag=0;
    NewsModle* modal=[self.dataArray[0] firstObject];
    [firstImageView sd_setImageWithURL:[NSURL URLWithString:[modal.icon parseURLString]]];
    UITapGestureRecognizer* gesture=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(imageClick:)];
    gesture.numberOfTapsRequired=1;
    gesture.numberOfTouchesRequired=1;
    firstImageView.userInteractionEnabled=YES;
    [firstImageView addGestureRecognizer:gesture];
    [cell.headerScrollView addSubview:firstImageView];
    
    cell.headerLable.text=self.titleLableArray[0];
    cell.headerLable.textAlignment=NSTextAlignmentLeft;
    [self.timer invalidate];
    self.timer=[NSTimer scheduledTimerWithTimeInterval:2 target:self selector:@selector(rollScrollView:) userInfo:nil repeats:YES];
    cell.headerPageController.numberOfPages=[self.dataArray[0] count];
    self.headerCell=cell;
    
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row>0) {
        NewsModle* modle=self.dataArray[indexPath.row];
        NSString*url=[NSString stringWithFormat:@"http://lol.data.shiwan.com/getArticleInfo/loldata?article_id=%@",modle.ID];
        HLDetailViewController*detailVC=[[HLDetailViewController alloc]initWithNibName:@"HLDetailViewController" bundle:nil];
        detailVC.URL=url;
        [self presentViewController:detailVC animated:YES completion:nil];
    }
    
}

-(void)rollScrollView:(NSTimer*)timer
{
    CGFloat x = _headerCell.headerScrollView.contentOffset.x;
    NSInteger count = [_dataArray.firstObject count];
    
    if (x == count * self.view.bounds.size.width)
    {
        _headerCell.headerScrollView.contentOffset = CGPointMake(0, 0);
        x = 0;
    }
    
    
    [UIView animateWithDuration:1 animations:^{
        if (x == (count - 1) * self.view.bounds.size.width)
        {
            _headerCell.headerPageController.currentPage = 0;
        }
        else
        {
            _headerCell.headerPageController.currentPage++;
        }
        _headerCell.headerScrollView.contentOffset = CGPointMake(x + self.view.bounds.size.width, 0);
        _headerCell.headerLable.text = _titleLableArray[_headerCell.headerPageController.currentPage];
    }];
    
}

-(void)imageClick:(UITapGestureRecognizer*)gesture
{
    NewsModle *model = self.dataArray[0][gesture.view.tag];
    NSString *url = [NSString stringWithFormat:@"http://lol.data.shiwan.com/getArticleInfo/loldata?article_id=%@",model.ID];
    HLDetailViewController*detailVC=[[HLDetailViewController alloc]initWithNibName:@"HLDetailViewController" bundle:nil];
    detailVC.URL=url;
    [self presentViewController:detailVC animated:YES completion:nil];
}


/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
